<?php require __DIR__ . '/../app/boot.php';
$u = me(); $f = null;
if ($u) { $q = $db->prepare('SELECT f.*, t.uid FROM files f JOIN tickets t ON t.n=f.tn WHERE f.id=?'); $q->execute([(int)($_GET['id'] ?? 0)]); $f = $q->fetch(PDO::FETCH_ASSOC); }
$p = $f ? __DIR__ . '/../app/uploads/t/' . $f['path'] : '';
if (!$f || ($f['uid'] !== $u['id'] && !admin()) || !is_file($p)) { http_response_code(404); exit; }
header('Content-Type: ' . $f['mime']); header('X-Content-Type-Options: nosniff'); header("Content-Security-Policy: default-src 'none'"); header('Cache-Control: private, max-age=3600'); readfile($p);
