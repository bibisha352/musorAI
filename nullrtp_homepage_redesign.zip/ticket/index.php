<?php require __DIR__ . '/../app/boot.php'; require __DIR__ . '/../app/img.php';
$u = me(); if (!$u) go('/login/'); $adminHost = strtolower(preg_replace('/:\\d+$/', '', (string)($_SERVER['HTTP_HOST'] ?? ''))) === 'admin.nullrtp.dev';
$q = $db->prepare('SELECT * FROM tickets WHERE n=? AND k1=? AND k2=?');
$q->execute([(int)($_GET['n'] ?? 0), (string)($_GET['a'] ?? ''), (string)($_GET['b'] ?? '')]);
$r = $q->fetch(PDO::FETCH_ASSOC); $mine = $r && $r['uid'] === $u['id'];
$old = $r && $mine && !admin() && $r['status'] === 'closed' && time() - (int)($r['closed_ts'] ?: $r['ts']) > 604800; // закрытые старше недели игроку недоступны
if (!$r || $old || (!$mine && !(admin() && $adminHost))) { http_response_code(404); readfile(__DIR__ . '/../404.html'); exit; }
$url = "/ticket/{$r['k1']}/{$r['k2']}/{$r['n']}";
if ($_SERVER['REQUEST_METHOD'] === 'POST') { chk(); $act = $_POST['act'] ?? '';
  if ($act === 'close') $db->prepare("UPDATE tickets SET status='closed', closed_ts=? WHERE n=?")->execute([time(), $r['n']]);
  elseif ($act === 'reply' && $r['status'] === 'open') { $b = trim((string)($_POST['body'] ?? ''));
    if (mb_strlen($b) >= 1 && mb_strlen($b) <= 3000) $db->prepare('INSERT INTO msgs(tn,uid,body,staff,ts) VALUES(?,?,?,?,?)')->execute([$r['n'], $u['id'], $b, $mine ? 0 : 1, time()]); files($r['n']); }
  go($url); }
$m = $db->prepare('SELECT * FROM msgs WHERE tn=? ORDER BY id'); $m->execute([$r['n']]); $msgs = $m->fetchAll(PDO::FETCH_ASSOC);
$fl = $db->prepare('SELECT * FROM files WHERE tn=? ORDER BY id'); $fl->execute([$r['n']]); $fls = $fl->fetchAll(PDO::FETCH_ASSOC);
top(t('ticket') . ' #' . $r['n'], 'support'); ?>
<section class="lcard wide">
  <h1><?= e($r['subject'] ?: t('ticket') . ' #' . $r['n']) ?></h1>
  <div class="tk-h"><span class="role">#<?= (int)$r['n'] ?></span><span class="role"><?= e(t('cat_' . $r['topic'])) ?></span><span class="role alt"><?= e(t('st_' . $r['status'])) ?></span><span class="role alt"><?= e(date('d M Y, H:i', (int)$r['ts'])) ?></span></div>
  <div class="thread">
    <div class="msg"><small><?= e($mine ? t('you') : 'user') ?></small><?= e($r['body']) ?></div>
    <?php foreach ($msgs as $x) echo '<div class="msg' . ($x['staff'] ? ' staff' : '') . '"><small>' . e($x['staff'] ? t('staff') : ($mine ? t('you') : 'user')) . ' · ' . e(date('d M, H:i', (int)$x['ts'])) . '</small>' . e($x['body']) . '</div>'; ?>
  </div>
  <?php if ($fls) { echo '<div class="atts">'; foreach ($fls as $f) echo '<a href="/ticket/file.php?id=' . (int)$f['id'] . '" target="_blank" rel="noopener"><img src="/ticket/file.php?id=' . (int)$f['id'] . '" alt="' . e($f['name']) . '"></a>'; echo '</div>'; } ?>
  <?php if ($r['status'] === 'open'): ?>
  <form method="post" class="tform" enctype="multipart/form-data"><input type="hidden" name="t" value="<?= csrf() ?>"><input type="hidden" name="act" value="reply">
    <textarea name="body" rows="4" maxlength="3000" required></textarea>
    <input type="file" name="f[]" accept="image/png,image/jpeg,image/webp,image/gif" multiple>
    <div class="pact" style="margin-top:0"><button class="btn-green" type="submit"><?= e(t('reply')) ?></button></div></form>
  <form method="post" style="margin-top:12px"><input type="hidden" name="t" value="<?= csrf() ?>"><input type="hidden" name="act" value="close"><button class="ghost" type="submit"><?= e(t('close_t')) ?></button></form>
  <?php else: ?><p><?= e(t('closed_note')) ?></p><?php endif; ?>
  <div class="pact"><a class="ghost" href="/support/"><?= e(t('back')) ?></a></div>
</section>
<?php bottom();
