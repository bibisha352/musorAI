<?php require __DIR__ . '/../app/boot.php'; require __DIR__ . '/../app/mail.php';
if (me()) go('/profile/');
$err = ''; $sent = ''; $v = ['login' => '', 'email' => ''];
if ($_SERVER['REQUEST_METHOD'] === 'POST') { $lg = trim((string)($_POST['login'] ?? '')); $em = strtolower(trim((string)($_POST['email'] ?? ''))); $pw = (string)($_POST['pass'] ?? ''); $v = ['login' => $lg, 'email' => $em];
  if (!preg_match('/^[A-Za-z0-9_]{3,20}$/', $lg)) $err = t('e_login');
  elseif (!filter_var($em, FILTER_VALIDATE_EMAIL) || strlen($em) > 100) $err = t('e_email');
  elseif (strlen($pw) < 8 || strlen($pw) > 72) $err = t('e_pass');
  elseif (empty($_POST['a1']) || empty($_POST['a2'])) $err = t('e_agree');
  elseif (!throttle(ipk('r'), 5, 3600)) $err = t('e_try');
  elseif (!captcha_ok()) $err = t('e_human');
  else { $q = $db->prepare('SELECT 1 FROM users WHERE lower(name)=lower(?) OR lower(email)=?'); $q->execute([$lg, $em]);
    if ($q->fetch()) $err = t('e_taken');
    else { $id = 'u' . bin2hex(random_bytes(6)); $tk = bin2hex(random_bytes(16));
      $db->prepare("INSERT INTO users(id,name,roles,joined,synced,email,pass,verified,evt,evts) VALUES(?,?,'[]',?,0,?,?,0,?,?)")->execute([$id, $lg, time(), $em, password_hash($pw, PASSWORD_DEFAULT), hash('sha256', $tk), time()]);
      if (send_conf($em, $lg, $tk)) $sent = $em; else { $db->prepare('DELETE FROM users WHERE id=?')->execute([$id]); $err = t('e_mail') . (!empty($C['mail_debug']) ? ' [' . ($GLOBALS['mail_err'] ?? '') . ']' : ''); } } } }
top(t('register')); plogo(); ?>
<section class="lcard modal"><a class="mx" href="/" aria-label="close">×</a>
<?php if ($sent) echo '<p style="margin:0;color:#e8eaee;font-size:14px;line-height:1.7">' . sprintf(e(t('reg_sent')), '<b>' . e($sent) . '</b>') . '</p>'; else { ?>
  <form method="post" class="tform mf">
    <input name="login" placeholder="<?= e(t('f_login')) ?>" required maxlength="20" autocomplete="username" value="<?= e($v['login']) ?>">
    <input type="password" name="pass" placeholder="<?= e(t('f_pass')) ?>" required maxlength="72" autocomplete="new-password">
    <input type="email" name="email" placeholder="<?= e(t('f_email')) ?>" required maxlength="100" autocomplete="email" value="<?= e($v['email']) ?>">
    <?= captcha_widget() ?>
    <label class="chk"><input type="checkbox" name="a1" value="1" required><span><?= sprintf(e(t('agree')), '<a href="/legal/terms/" target="_blank">' . e(t('lk_terms')) . '</a>') ?></span></label>
    <label class="chk"><input type="checkbox" name="a2" value="1" required><span><?= sprintf(e(t('agree')), '<a href="/legal/privacy/" target="_blank">' . e(t('lk_priv')) . '</a>') ?></span></label>
    <?php if ($err) echo '<p class="err">' . e($err) . '</p>'; ?>
    <button class="btn-green wide" type="submit"><?= e(t('register')) ?></button>
  </form><p class="mlinks"><span><?= e(t('have_acc')) ?> <a href="/login/"><?= e(t('login')) ?></a></span></p>
<?php } ?></section>
<?php bottom();
