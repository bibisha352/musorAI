<?php require __DIR__ . '/../app/boot.php'; require __DIR__ . '/../app/card.php';
$q = $db->prepare('SELECT * FROM users WHERE slug=?'); $q->execute([strtolower((string)($_GET['s'] ?? ''))]); $p = $q->fetch(PDO::FETCH_ASSOC);
if (!$p) { http_response_code(404); readfile(__DIR__ . '/../404.html'); exit; }
$me = me(); $own = $me && $me['id'] === $p['id'];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $me && !$own) { chk();
  $db->prepare('INSERT INTO votes(uid,target,v) VALUES(?,?,?) ON CONFLICT(uid,target) DO UPDATE SET v=excluded.v')->execute([$me['id'], $p['id'], ($_POST['v'] ?? '') === 'up' ? 1 : -1]); go('/u/' . $p['slug'] . '/'); }
if (!$own && empty($_SESSION['vw'][$p['id']])) { $_SESSION['vw'][$p['id']] = 1; $db->prepare('UPDATE users SET views=views+1 WHERE id=?')->execute([$p['id']]); $p['views']++; }
top($p['name']); pcard($p, $own); bottom();
