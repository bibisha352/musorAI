document.addEventListener("DOMContentLoaded", () => {
    console.log("[NULLRTP] Модуль асинхронного поиска search.js успешно подключен.");

    // Функция быстрого поиска (клиентский рендеринг для высокой нагрузки)
    async function initSearch() {
        try {
            // Подгружаем разрешенные роли и темы из нашего легкого tools.json файла
            const response = await fetch('/data/tools.json');
            const data = await response.json();
            
            console.log("[SEARCH] Доступные роли для фильтрации профилей:", data.allowed_display_roles);
        } catch (error) {
            console.error("[SEARCH] Ошибка подгрузки локальной базы данных JSON:", error);
        }
    }

    initSearch();
});
