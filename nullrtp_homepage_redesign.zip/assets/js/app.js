(() => {
  // защита: только наш домен, без iframe, без копирования/инспекции
  if (!/(^|\.)nullrtp\.dev$|^localhost$|^127\./.test(location.hostname)) { document.documentElement.innerHTML = ""; return; }
  if (top !== self) top.location = self.location;
  const field = (t) => (t.closest ? t : t.parentElement).closest("input,textarea");
  addEventListener("contextmenu", (e) => e.preventDefault());
  addEventListener("dragstart", (e) => e.preventDefault());
  addEventListener("selectstart", (e) => { if (!field(e.target)) e.preventDefault(); });
  addEventListener("copy", (e) => { if (!field(e.target)) e.preventDefault(); });
  addEventListener("keydown", (e) => { const k = e.key.toLowerCase(); if (e.key === "F12" || ((e.ctrlKey || e.metaKey) && (["u", "s", "p"].includes(k) || (e.shiftKey && ["i", "j", "c"].includes(k))))) e.preventDefault(); });
  // поиск в support
  const q = document.getElementById("q");
  if (q) q.addEventListener("input", () => { const v = q.value.toLowerCase(); document.querySelectorAll("[data-s]").forEach((el) => (el.hidden = !el.dataset.s.toLowerCase().includes(v))); });
  // закрыть меню профиля по клику вне
  document.addEventListener("click", (e) => document.querySelectorAll(".dd[open],.lg[open]").forEach((d) => { if (!d.contains(e.target)) d.open = false; }));
})();
(() => {
  const l = document.getElementById("lang");
  if (l) l.addEventListener("change", () => { location.search = "?lang=" + l.value; });
  const ck = document.getElementById("ck"), b = document.getElementById("ckb");
  const dm = /nullrtp\.dev$/.test(location.hostname) ? ";domain=.nullrtp.dev" : "";
  let seen = /(^|; )ck=1/.test(document.cookie); try { seen = seen || !!localStorage.getItem("ck"); } catch (e) {}
  if (ck && !seen) ck.hidden = false;
  if (b) b.addEventListener("click", () => { try { localStorage.setItem("ck", "1"); } catch (e) {} document.cookie = "ck=1;path=/;max-age=31536000;samesite=lax" + dm + (location.protocol === "https:" ? ";secure" : ""); ck.hidden = true; });
})();
(() => {
  const b = document.querySelectorAll(".cats button");
  b.forEach((x) => x.addEventListener("click", () => { b.forEach((y) => y.classList.toggle("on", y === x)); document.querySelectorAll(".shop .card").forEach((c) => { c.hidden = x.dataset.c !== "all" && c.dataset.c !== x.dataset.c; }); }));
})();
