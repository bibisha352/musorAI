(() => {
  const touch = matchMedia("(pointer: coarse)").matches;
  const saveData = !!(navigator.connection && (navigator.connection.saveData || /2g|3g/.test(navigator.connection.effectiveType || "")));
  const lite = touch || saveData || matchMedia("(prefers-reduced-motion: reduce)").matches;
  document.documentElement.classList.toggle("lite-mode", lite);
  if (lite) return;
  const $ = (s, r = document) => [...r.querySelectorAll(s)];
  const mk = (tag, cls, parent = document.body) => { const e = document.createElement(tag); e.className = cls; parent.appendChild(e); return e; };
  const CH = "01アイウエオカキクケコ<>/\\[]{}#@$%&*!?|";
  const rnd = () => CH[(Math.random() * CH.length) | 0];
  const type = (el, txt, speed = 28) => new Promise((res) => { let i = 0; el.textContent = ""; const t = setInterval(() => { el.textContent = txt.slice(0, ++i); if (i >= txt.length) { clearInterval(t); res(); } }, speed); });
  const ready = (cb) => { if (!document.getElementById("preloader")) return cb(); const t = setInterval(() => { if (!document.getElementById("preloader")) { clearInterval(t); setTimeout(cb, 150); } }, 100); };
  const scramble = (el) => { const fin = el.dataset.t || (el.dataset.t = el.textContent); let f = 0; clearInterval(el._s); el._s = setInterval(() => { el.textContent = [...fin].map((c, i) => (i < f / 2 || c === " " ? c : rnd())).join(""); if (++f > fin.length * 2) { clearInterval(el._s); el.textContent = fin; } }, 30); };

  document.documentElement.classList.add("fx");

  // оверлеи: прогресс, сканлайны, виньетка
  const bar = mk("div", "fx-progress"); mk("div", "fx-scan"); mk("div", "fx-vig");
  const head = document.querySelector("header");
  const onScroll = () => { const h = document.documentElement; bar.style.transform = `scaleX(${scrollY / Math.max(1, h.scrollHeight - innerHeight)})`; if (head) head.classList.toggle("scrolled", scrollY > 20); };
  addEventListener("scroll", onScroll, { passive: true }); onScroll();

  // дождь из кода поверх видео
  const rc = mk("canvas", "fx-rain"), rx = rc.getContext("2d"); const fs = 16; let cols, drops, last = 0;
  const size = () => { rc.width = innerWidth; rc.height = innerHeight; cols = Math.ceil(innerWidth / fs); drops = Array.from({ length: cols }, () => Math.random() * -50); };
  size(); addEventListener("resize", size);
  const rain = (t) => { requestAnimationFrame(rain); if (t - last < 50) return; last = t;
    rx.globalCompositeOperation = "destination-out"; rx.fillStyle = "rgba(0,0,0,.14)"; rx.fillRect(0, 0, rc.width, rc.height);
    rx.globalCompositeOperation = "source-over"; rx.font = fs + "px JetBrains Mono, monospace";
    for (let i = 0; i < cols; i++) { const y = drops[i] * fs; rx.fillStyle = Math.random() > .96 ? "#d8ffe8" : "#2ecc71"; rx.fillText(rnd(), i * fs, y); if (y > rc.height && Math.random() > .975) drops[i] = 0; drops[i]++; } };
  requestAnimationFrame(rain);

  // курсор: свечение + шлейф из символов
  if (!touch) {
    const glow = mk("div", "fx-glow"), tc = mk("canvas", "fx-trail"), tx = tc.getContext("2d");
    let mx = innerWidth / 2, my = innerHeight / 2, gx = mx, gy = my, ps = [];
    const rs = () => { tc.width = innerWidth; tc.height = innerHeight; }; rs(); addEventListener("resize", rs);
    addEventListener("mousemove", (e) => { mx = e.clientX; my = e.clientY; if (Math.random() > .35) ps.push({ x: mx, y: my, vx: (Math.random() - .5) * 1.2, vy: Math.random() * 1.5 + .4, l: 1, c: rnd() }); });
    const loop = () => { gx += (mx - gx) * .12; gy += (my - gy) * .12; glow.style.transform = `translate(${gx}px,${gy}px)`;
      tx.clearRect(0, 0, tc.width, tc.height); tx.font = "13px JetBrains Mono, monospace";
      ps = ps.filter((p) => p.l > 0); for (const p of ps) { p.x += p.vx; p.y += p.vy; p.l -= .025; tx.fillStyle = `rgba(46,204,113,${p.l})`; tx.fillText(p.c, p.x, p.y); }
      requestAnimationFrame(loop); };
    loop();
  }

  // взрыв символов по клику
  addEventListener("click", (e) => { for (let i = 0; i < 12; i++) { const s = mk("span", "fx-burst"); s.textContent = rnd(); const a = (Math.PI * 2 * i) / 12 + Math.random() * .4, d = 40 + Math.random() * 50; s.style.cssText = `left:${e.clientX}px;top:${e.clientY}px;--dx:${Math.cos(a) * d}px;--dy:${Math.sin(a) * d}px`; setTimeout(() => s.remove(), 700); } });

  // скрэмбл текста при наведении на логотип и меню
  $("nav a, .logo").forEach((a) => a.addEventListener("mouseenter", () => scramble(a.querySelector("span") || a)));

  // плавный уход со страницы
  document.addEventListener("click", (e) => { const a = e.target.closest("a"); if (!a || a.target || e.metaKey || e.ctrlKey || a.origin !== location.origin || (a.pathname === location.pathname && a.hash)) return; e.preventDefault(); document.body.classList.add("fx-out"); setTimeout(() => (location.href = a.href), 300); });
  addEventListener("pageshow", () => document.body.classList.remove("fx-out"));

  // подсветка пункта меню при скролле
  const links = $('nav a[href*="#"]');
  if (links.length) { const spy = new IntersectionObserver((en) => en.forEach((e) => { if (e.isIntersecting) links.forEach((l) => l.classList.toggle("active", l.hash === "#" + e.target.id)); }), { rootMargin: "-40% 0px -50% 0px" }); $(".section[id]").forEach((s) => spy.observe(s)); }

  // глитч заголовков
  $("h1, .big-404").forEach((h) => { h.classList.add("gl"); h.dataset.text = h.textContent; (function loop() { setTimeout(() => { h.classList.add("go"); setTimeout(() => h.classList.remove("go"), 450); loop(); }, 2500 + Math.random() * 4000); })(); });

  // кнопки: ripple без магнитного смещения — геометрия элементов остаётся стабильной.
  $(".btn-green").forEach((b) => b.addEventListener("click", (e) => { const r = b.getBoundingClientRect(), s = mk("span", "fx-rip", b); s.style.left = e.clientX - r.left + "px"; s.style.top = e.clientY - r.top + "px"; setTimeout(() => s.remove(), 700); }));

  // 3D-наклон карточек со световым пятном
  $(".grid .card, .module-card, .feature-card").forEach((c) => {
    c.addEventListener("mousemove", (e) => { const r = c.getBoundingClientRect(), x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height; c.style.setProperty("--mx", x * 100 + "%"); c.style.setProperty("--my", y * 100 + "%"); c.style.transform = `perspective(700px) rotateX(${(.5 - y) * 8}deg) rotateY(${(x - .5) * 10}deg) translateY(-3px)`; });
    c.addEventListener("mouseleave", () => (c.style.transform = ""));
  });

  // мягкий параллакс hero: декоративные орбиты едва реагируют на движение мыши
  const homeHero = document.querySelector(".hhero");
  const orbitField = document.querySelector(".orbit-field");
  if (homeHero && orbitField && !touch) {
    homeHero.addEventListener("pointermove", (e) => {
      const r = homeHero.getBoundingClientRect();
      const x = (e.clientX - r.left) / r.width - .5;
      const y = (e.clientY - r.top) / r.height - .5;
      orbitField.style.setProperty("--px", `${x * 18}px`);
      orbitField.style.setProperty("--py", `${y * 18}px`);
    });
    homeHero.addEventListener("pointerleave", () => {
      orbitField.style.setProperty("--px", "0px");
      orbitField.style.setProperty("--py", "0px");
    });
  }

  // подготовка к появлению блоков
  const targets = [...new Set($("main > .kicker, main > h1, main > .lead, .grid > .card, .section > *, main > .card, .center-404 > *, .band, .feat, .home-reveal"))];
  targets.forEach((t) => t.classList.add("rv"));

  // счётчики
  const count = (el) => { const m = el.textContent.match(/^(\d[\d,]*)(.*)$/); if (!m) return; const to = +m[1].replace(/,/g, ""), suf = m[2], t0 = performance.now(); const step = (t) => { const p = Math.min(1, (t - t0) / 1600), e = 1 - Math.pow(1 - p, 3); el.textContent = Math.round(to * e).toLocaleString("en-US") + suf; if (p < 1) requestAnimationFrame(step); }; step(t0); };

  // терминал: печатается построчно
  const term = document.querySelector(".term");
  const lines = term ? $("div", term).map((d) => { const tn = d.firstElementChild.nextSibling, full = tn.nodeValue; tn.nodeValue = ""; d.style.visibility = "hidden"; return { d, tn, full }; }) : [];

  ready(() => {
    const k = document.querySelector("main > .kicker");
    if (k) { const t = k.textContent; k.textContent = ""; k.style.opacity = 1; k.classList.remove("rv"); type(k, t, 45).then(() => k.classList.add("caret")); }

    const io = new IntersectionObserver((en) => {
      en.filter((e) => e.isIntersecting).forEach((e, i) => { const t = e.target; io.unobserve(t); t.style.setProperty("--d", i * .12 + "s"); t.classList.add("in"); setTimeout(() => t.classList.remove("rv", "in"), 1000 + i * 120); });
    }, { threshold: .15 });
    targets.filter((t) => t !== k).forEach((t) => io.observe(t));

    const co = new IntersectionObserver((en) => en.forEach((e) => { if (e.isIntersecting) { co.unobserve(e.target); count(e.target); } }), { threshold: .6 });
    $(".stat b, .card p span").forEach((el) => co.observe(el));

    if (term) {
      const to = new IntersectionObserver(async (en) => {
        if (!en[0].isIntersecting) return; to.disconnect();
        for (const [i, l] of lines.entries()) { l.d.style.visibility = ""; l.d.classList.add("caret"); await type(l.tn, l.full, 22); if (i < lines.length - 1) l.d.classList.remove("caret"); await new Promise((r) => setTimeout(r, 180)); }
        const last = lines[lines.length - 1].d; last.innerHTML = last.innerHTML.replace("online", '<b class="live">online</b>');
      }, { threshold: .5 });
      to.observe(term);
    }
  });
})();
