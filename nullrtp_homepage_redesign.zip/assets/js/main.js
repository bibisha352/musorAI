document.addEventListener("DOMContentLoaded", () => {
  const clickSound = new Audio("/assets/audio/click.mp3");
  const lowPower = matchMedia("(pointer: coarse)").matches || (navigator.connection && (navigator.connection.saveData || /2g|3g/.test(navigator.connection.effectiveType || "")));
  document.documentElement.classList.toggle("lite-mode", !!lowPower);
  clickSound.preload = lowPower ? "none" : "auto";
  clickSound.volume = 0.25;
  if (!lowPower) clickSound.load();
  const matrixVideo = document.querySelector(".matrix-video");
  if (matrixVideo && !lowPower) { matrixVideo.src = matrixVideo.dataset.src || "/assets/video/matrix.mp4"; matrixVideo.load(); }

  document.querySelectorAll("nav a, .logo").forEach((node) => {
    node.addEventListener("click", () => {
      clickSound.currentTime = 0;
      clickSound.play().catch(() => {});
    });
  });

  const root = document.getElementById("preloader");
  const text = document.getElementById("pre-text");
  if (!root || !text) return;
  try { if (sessionStorage.getItem("pre")) { root.remove(); return; } sessionStorage.setItem("pre", "1"); } catch (e) {}
  text.className = "pre-text decoded";
  const loader = document.createElement("div");
  loader.className = "pre-load";
  loader.innerHTML = '<div class="pre-bar"><i></i></div><span class="pre-pct">0%</span>';
  root.appendChild(loader);
  const bar = loader.querySelector("i"), pct = loader.querySelector("span");

  // настоящая загрузка: у каждой задачи своя доля, 100% только когда всё готово
  const video = document.querySelector(".matrix-video");
  const W = { dom: 10, fonts: 10, audio: 10, load: 25, video: 45 };
  const done = { dom: 1, fonts: 0, audio: 0, load: document.readyState === "complete" ? 1 : 0 };
  const fin = (k) => () => { done[k] = 1; };
  (document.fonts ? document.fonts.ready : Promise.resolve()).then(fin("fonts"), fin("fonts"));
  if (clickSound.readyState >= 4) done.audio = 1;
  else { clickSound.addEventListener("canplaythrough", fin("audio"), { once: true }); clickSound.addEventListener("error", fin("audio"), { once: true }); setTimeout(fin("audio"), 3000); }
  if (!done.load) window.addEventListener("load", fin("load"), { once: true });
  let vErr = false;
  if (video) video.addEventListener("error", () => { vErr = true; });
  const videoFrac = () => {
    if (!video || vErr || video.readyState >= 4) return 1;
    const d = video.duration;
    if (!d || !isFinite(d) || !video.buffered.length) return video.readyState >= 1 ? 0.05 : 0;
    return Math.min(0.98, video.buffered.end(video.buffered.length - 1) / d);
  };
  const real = () => { const f = { ...done, video: videoFrac() }; let s = 0; for (const k in W) s += W[k] * f[k]; return s / 100; };

  let shown = 0, forced = false, removed = false;
  setTimeout(() => { forced = true; }, 12000); // страховка, чтобы не зависнуть на медленном соединении
  const remove = () => { if (removed || !root.isConnected) return; removed = true; root.remove(); };

  const tick = () => {
    const target = forced ? 1 : real();
    shown += Math.max((target - shown) * 0.1, target > shown ? 0.01 : 0);
    if (shown > target) shown = target;
    const p = Math.min(1, shown);
    bar.style.width = p * 100 + "%";
    pct.textContent = (p >= 1 ? 100 : Math.min(99, Math.round(p * 100))) + "%";
    if (p < 1 || target < 1) { requestAnimationFrame(tick); return; }
    setTimeout(() => {
      root.classList.add("fade");
      root.addEventListener("transitionend", remove, { once: true });
      setTimeout(remove, 600);
    }, 300);
  };
  requestAnimationFrame(tick);
});
