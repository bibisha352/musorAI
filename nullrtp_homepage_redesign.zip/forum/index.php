<?php require __DIR__ . '/../app/boot.php'; require __DIR__ . '/../app/forum.php';
$u = me(); $adm = admin();
$cid = (int)($_GET['c'] ?? 0); $tid = (int)($_GET['t'] ?? 0); $nid = (int)($_GET['new'] ?? 0); // /forum/ · ?c=раздел · ?t=тема · ?new=раздел
require __DIR__ . '/../app/forum/' . ($tid ? 'topic' : ($nid ? 'newtopic' : (($cid || isset($_GET['l'])) ? 'category' : 'home'))) . '.php';
