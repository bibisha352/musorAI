<?php require __DIR__ . '/../../app/boot.php'; require __DIR__ . '/../../app/img.php'; require __DIR__ . '/../../app/card.php';
$u = me(); if (!$u) go('/login/'); $err = ''; $id = $u['id'];
if ($_SERVER['REQUEST_METHOD'] === 'POST') { chk();
  if (($_POST['act'] ?? '') === 'dunlink') { $db->prepare('UPDATE users SET did=NULL, dname=NULL WHERE id=?')->execute([$id]); go('/profile/settings/'); }
  $b = (int)($_POST['banner'] ?? 0); if (!isset($BN[$b])) $b = 0;
  $sl = strtolower(trim((string)($_POST['slug'] ?? '')));
  if ($sl !== '') { $q = $db->prepare('SELECT id FROM users WHERE slug=? AND id<>?'); $q->execute([$sl, $id]); if (!preg_match('/^[a-z0-9_]{3,20}$/', $sl) || $q->fetch()) $err = t('e_slug'); }
  $dir = dirname(__DIR__, 2) . '/app/uploads/u'; $av = (int)$u['avu']; $bnu = (int)$u['bnu'];
  foreach (['avatar' => ['av', 256, 256], 'banner' => ['bn', 1472, 300]] as $f => [$k, $w, $h]) {
    if (!empty($_POST['rm_' . $k])) { @unlink("$dir/$id-$k.jpg"); if ($k === 'av') $av = 0; else $bnu = 0; }
    elseif (!$err && !empty($_FILES[$f]['tmp_name']) && $_FILES[$f]['error'] === UPLOAD_ERR_OK) {
      if ($_FILES[$f]['size'] <= 3145728 && jpg($_FILES[$f]['tmp_name'], "$dir/$id-$k.jpg", $w, $h)) { if ($k === 'av') $av = time(); else $bnu = time(); } else $err = t('e_img'); } }
  if (!$err) { $db->prepare('UPDATE users SET bio=?,banner=?,color=?,slug=?,avu=?,bnu=? WHERE id=?')->execute([mb_substr(trim((string)($_POST['bio'] ?? '')), 0, 200), $b, col($_POST['color'] ?? ''), $sl ?: null, $av, $bnu, $id]); go('/profile/'); } }
top(t('settings'), 'profile'); ?>
<section class="lcard wide"><h1><?= e(t('settings')) ?></h1>
  <form method="post" class="tform" enctype="multipart/form-data"><input type="hidden" name="t" value="<?= csrf() ?>">
    <label><?= e(t('slug')) ?> · nullrtp.dev/u/…</label><input name="slug" maxlength="20" value="<?= e($u['slug']) ?>">
    <label><?= e(t('bio')) ?></label><textarea name="bio" rows="3" maxlength="200"><?= e($u['bio']) ?></textarea>
    <label><?= e(t('banner')) ?></label>
    <div class="swatches"><?php foreach ($BN as $i => $g) echo '<label><input type="radio" name="banner" value="' . $i . '"' . ($i === (int)$u['banner'] ? ' checked' : '') . '><span style="background-image:' . $g . '"></span></label>'; ?></div>
    <label><?= e(t('up_bn')) ?> (1472×300)</label><input type="file" name="banner" accept="image/png,image/jpeg,image/webp,image/gif"><label><input type="checkbox" name="rm_bn" value="1"> <?= e(t('remove')) ?></label>
    <label><?= e(t('up_av')) ?></label><input type="file" name="avatar" accept="image/png,image/jpeg,image/webp,image/gif"><label><input type="checkbox" name="rm_av" value="1"> <?= e(t('remove')) ?></label>
    <label><?= e(t('color')) ?></label><input type="color" name="color" value="<?= e(col($u['color']) ?: '#2ecc71') ?>">
    <?php if ($err) echo '<p class="err">' . e($err) . '</p>'; ?>
    <button class="btn-green" type="submit"><?= e(t('save')) ?></button>
  </form></section>
<?php dcard($u); devcard($u); bottom();
