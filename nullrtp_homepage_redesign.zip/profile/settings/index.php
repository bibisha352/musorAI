<?php require __DIR__ . '/../../app/boot.php';if(!me())go('/login/');go('/profile/?tab=settings');
