<?php require __DIR__ . '/../app/boot.php'; require __DIR__ . '/../app/card.php';
$u = me(); if (!$u) go('/login/');
top(t('myprofile'), 'profile'); pcard($u, true); bottom();
