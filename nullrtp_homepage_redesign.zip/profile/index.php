<?php
require __DIR__ . '/../app/boot.php';require __DIR__ . '/../app/img.php';require __DIR__ . '/../app/card.php';
$u=me();if(!$u)go('/login/');$tab=(string)($_GET['tab']??'overview');if(!in_array($tab,['overview','settings','discord','devices'],true))$tab='overview';$err='';$id=$u['id'];
if($_SERVER['REQUEST_METHOD']==='POST'){chk();
 if(($_POST['act']??'')==='dunlink'){$db->prepare('UPDATE users SET did=NULL,dname=NULL WHERE id=?')->execute([$id]);go('/profile/?tab=discord');}
 $bn=(int)($_POST['banner']??0);if(!isset($BN[$bn]))$bn=0;$slug=strtolower(trim((string)($_POST['slug']??'')));
 if($slug!==''){$q=$db->prepare('SELECT id FROM users WHERE slug=? AND id<>?');$q->execute([$slug,$id]);if(!preg_match('/^[a-z0-9_]{3,20}$/',$slug)||$q->fetch())$err=t('e_slug');}
 $dir=dirname(__DIR__).'/app/uploads/u';$av=(int)$u['avu'];$bnu=(int)$u['bnu'];
 foreach(['avatar'=>['av',256,256],'banner'=>['bn',1472,300]] as $f=>[$key,$w,$h]){
  if(!empty($_POST['rm_'.$key])){@unlink("$dir/$id-$key.jpg");if($key==='av')$av=0;else$bnu=0;}
  elseif(!$err&&!empty($_FILES[$f]['tmp_name'])&&$_FILES[$f]['error']===UPLOAD_ERR_OK){if($_FILES[$f]['size']<=3145728&&jpg($_FILES[$f]['tmp_name'],"$dir/$id-$key.jpg",$w,$h)){if($key==='av')$av=time();else$bnu=time();}else$err=t('e_img');}
 }
 if(!$err){$db->prepare('UPDATE users SET bio=?,banner=?,color=?,slug=?,avu=?,bnu=? WHERE id=?')->execute([mb_substr(trim((string)($_POST['bio']??'')),0,200),$bn,col($_POST['color']??''),$slug?:null,$av,$bnu,$id]);go('/profile/?tab=settings&saved=1');}$tab='settings';
}
$tabs=['overview'=>'ОБЗОР','settings'=>'НАСТРОЙКИ ПРОФИЛЯ','discord'=>'DISCORD','devices'=>'УСТРОЙСТВА'];top(t('myprofile'),'profile');
?>
<section class="profile-shell"><div class="profile-head"><div><span class="profile-overline">ACCOUNT / NULLRTP</span><h1>ЛИЧНЫЙ КАБИНЕТ</h1></div><span class="profile-version">PROFILE v0.2</span></div>
<nav class="profile-tabs" aria-label="Разделы профиля"><?php foreach($tabs as $key=>$label):?><a href="/profile/?tab=<?=e($key)?>"<?=$tab===$key?' class="active"':''?>><?=e($label)?></a><?php endforeach;?></nav>
<?php if($tab==='overview'):?><?php pcard($u,true);?><div class="profile-quick">
<a href="/profile/?tab=settings"><small>01 / CUSTOMIZE</small><b>Настройки профиля</b><span>Аватар, баннер, описание и цвет имени</span><i>↗</i></a>
<a href="/profile/?tab=discord"><small>02 / CONNECTION</small><b>Discord</b><span>Подключение Discord-аккаунта</span><i>↗</i></a>
<a href="/profile/?tab=devices"><small>03 / SECURITY</small><b>Устройства</b><span>Активные сессии и выход с устройств</span><i>↗</i></a>
</div>
<?php elseif($tab==='settings'):?><section class="lcard wide profile-panel"><div class="profile-panel-head"><span>ACCOUNT / 01</span><b>НАСТРОЙКИ ПРОФИЛЯ</b></div><?php if(!empty($_GET['saved'])):?><p class="profile-success">Изменения сохранены.</p><?php endif;?>
<form method="post" action="/profile/?tab=settings" class="tform" enctype="multipart/form-data"><input type="hidden" name="t" value="<?=csrf()?>"><label><?=e(t('slug'))?> · nullrtp.dev/u/…</label><input name="slug" maxlength="20" value="<?=e($u['slug'])?>"><label><?=e(t('bio'))?></label><textarea name="bio" rows="3" maxlength="200"><?=e($u['bio'])?></textarea>
<label><?=e(t('banner'))?></label><div class="swatches"><?php foreach($BN as $i=>$g)echo '<label><input type="radio" name="banner" value="'.$i.'"'.($i===(int)$u['banner']?' checked':'').'><span style="background-image:'.$g.'"></span></label>';?></div>
<label><?=e(t('up_bn'))?> (1472×300)</label><input type="file" name="banner" accept="image/png,image/jpeg,image/webp"><label><input type="checkbox" name="rm_bn" value="1"> <?=e(t('remove'))?></label>
<label><?=e(t('up_av'))?></label><input type="file" name="avatar" accept="image/png,image/jpeg,image/webp"><label><input type="checkbox" name="rm_av" value="1"> <?=e(t('remove'))?></label><label><?=e(t('color'))?></label><input type="color" name="color" value="<?=e(col($u['color'])?:'#2ecc71')?>"><?php if($err)echo '<p class="err">'.e($err).'</p>';?><button class="btn-green" type="submit"><?=e(t('save'))?></button></form></section>
<?php elseif($tab==='discord'):?><?php dcard($u);?><?php else:?><?php devcard($u);?><?php endif;?></section><?php bottom();?>
