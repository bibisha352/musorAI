<?php require __DIR__ . '/../../app/boot.php';
$u = me(); if (!$u) go('/login/');
if ($_SERVER['REQUEST_METHOD'] === 'POST') { chk(); $db->prepare('UPDATE sess SET ended=1 WHERE sid=? AND uid=?')->execute([(string)($_POST['sid'] ?? ''), $u['id']]); }
go('/profile/settings/#devices');
