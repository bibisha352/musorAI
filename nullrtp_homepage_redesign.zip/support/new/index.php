<?php require __DIR__ . '/../../app/boot.php'; require __DIR__ . '/../../app/img.php';
$u = me(); $err = ''; $cats = ['question', 'bug', 'account', 'other'];
if (!$u) { top(t('send_request'), 'support'); logincard('/support/new/'); bottom(); exit; }
if ($_SERVER['REQUEST_METHOD'] === 'POST') { chk();
  $c = $_POST['cat'] ?? ''; $s = trim((string)($_POST['subject'] ?? '')); $b = trim((string)($_POST['body'] ?? ''));
  $q = $db->prepare('SELECT COUNT(*) FROM tickets WHERE uid=? AND ts>?'); $q->execute([$u['id'], time() - 600]);
  if (!in_array($c, $cats, true) || mb_strlen($s) < 3 || mb_strlen($s) > 120 || mb_strlen($b) < 10 || mb_strlen($b) > 3000) $err = t('e_len');
  elseif ($q->fetchColumn() >= 3) $err = t('e_rate');
  elseif (!files()) $err = t('e_file');
  elseif (!captcha_ok()) $err = t('e_human');
  else { $k1 = bin2hex(random_bytes(8)); $k2 = bin2hex(random_bytes(8));
    $db->prepare('INSERT INTO tickets(k1,k2,uid,topic,subject,body,ts) VALUES(?,?,?,?,?,?,?)')->execute([$k1, $k2, $u['id'], $c, $s, $b, time()]);
    $tn = $db->lastInsertId(); files($tn); go("/ticket/$k1/$k2/$tn"); } }
top(t('send_request'), 'support'); ?>
<section class="lcard wide"><h1><?= e(t('send_request')) ?></h1>
  <form method="post" class="tform" enctype="multipart/form-data"><input type="hidden" name="t" value="<?= csrf() ?>">
    <label><?= e(t('how_help')) ?></label>
    <select name="cat"><?php foreach ($cats as $c) echo '<option value="' . $c . '">' . e(t('cat_' . $c)) . '</option>'; ?></select>
    <label><?= e(t('subject')) ?></label><input name="subject" maxlength="120" required>
    <label><?= e(t('desc')) ?></label><textarea name="body" rows="8" maxlength="3000" required></textarea>
    <label><?= e(t('files')) ?></label><input type="file" name="f[]" accept="image/png,image/jpeg,image/webp,image/gif" multiple>
    <?= captcha_widget() ?>
    <?php if ($err) echo '<p class="err">' . e($err) . '</p>'; ?>
    <button class="btn-green" type="submit"><?= e(t('send')) ?></button>
  </form></section>
<?php bottom();
