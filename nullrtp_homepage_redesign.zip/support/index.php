<?php require __DIR__ . '/../app/boot.php';
$u = me(); $adm = $u && admin();
function trows($rows, $who = false) { foreach ($rows as $r) echo '<a class="trow" data-s="' . e(($r['subject'] ?? '') . ' ' . $r['topic'] . ' ' . ($r['name'] ?? '')) . '" href="/ticket/' . $r['k1'] . '/' . $r['k2'] . '/' . $r['n'] . '"><b>#' . $r['n'] . '</b><span>' . e($r['subject'] ?: $r['topic']) . ($who ? ' <small>· ' . e($r['name'] ?? '?') . '</small>' : '') . '</span><em class="st">' . e(t('st_' . $r['status'])) . '</em><small>' . e(date('d M Y', (int)$r['ts'])) . '</small></a>'; }
$op = $cl = $al = [];
if ($u) { $q = $db->prepare('SELECT * FROM tickets WHERE uid=? ORDER BY n DESC LIMIT 100'); $q->execute([$u['id']]);
  foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $r) { if ($r['status'] === 'open') $op[] = $r; elseif (time() - (int)($r['closed_ts'] ?: $r['ts']) <= 604800) $cl[] = $r; } // закрытые старше недели игроку не показываются
  if ($adm) $al = $db->query('SELECT t.*, u.name FROM tickets t LEFT JOIN users u ON u.id=t.uid ORDER BY t.n DESC LIMIT 300')->fetchAll(PDO::FETCH_ASSOC); }
top(t('support'), 'support'); ?>
<section class="hero c">
  <h1><?= e(t('help_title')) ?></h1>
  <input id="q" class="search" type="search" placeholder="<?= e(t('search_ph')) ?>" autocomplete="off">
  <p class="lead"><?= e(t('need_help')) ?></p>
  <a class="btn-green big" href="/support/new/"><?= e(t('send_request')) ?></a>
</section>
<?php if ($u): ?>
<section class="section" id="tickets" style="max-width:760px;margin:0 auto">
  <p class="kicker"><?= e(t('my_open')) ?></p>
  <div class="tlist"><?php trows($op); if (!$op) echo '<p>' . e(t('no_tickets')) . '</p>'; ?></div>
  <?php if ($cl): ?><p class="kicker" style="margin-top:28px"><?= e(t('my_closed')) ?></p><div class="tlist"><?php trows($cl); ?></div><?php endif; ?>
  <?php if ($adm): ?><p class="kicker" style="margin-top:36px"><?= e(t('alltickets')) ?></p><div class="tlist"><?php trows($al, true); ?></div><?php endif; ?>
</section>
<?php endif; bottom();
