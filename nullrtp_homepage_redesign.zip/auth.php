<?php require __DIR__ . '/app/boot.php';
function oauth_error($key) { go('/login/?oauth=' . rawurlencode($key)); }
function oauth_name($raw) {
  global $db; $base=substr(preg_replace('/[^A-Za-z0-9_]/','',(string)$raw) ?: 'User',0,16); if(strlen($base)<3)$base='User'.$base; $name=$base;
  for($i=0;$i<20;$i++){ $q=$db->prepare('SELECT 1 FROM users WHERE lower(name)=lower(?) LIMIT 1');$q->execute([$name]);if(!$q->fetch())return $name;$name=substr($base,0,14).random_int(10,99); }
  return 'User'.bin2hex(random_bytes(3));
}
function oauth_login($provider) {
  global $C,$db; $saved=$_SESSION['oauth_login']??null;
  if(!is_array($saved)||($saved['provider']??'')!==$provider||!hash_equals((string)($saved['state']??''),(string)($_GET['state']??''))||time()-(int)($saved['time']??0)>600)oauth_error('failed');
  unset($_SESSION['oauth_login']); if(empty($_GET['code']))oauth_error('failed');
  $base=rtrim((string)($C['site']??'https://nullrtp.dev'),'/');$redirect=$base.'/auth.php?oauth_callback='.$provider;
  if($provider==='discord'){
    if(empty($C['client_id'])||empty($C['client_secret']))oauth_error('setup');
    $token=post('https://discord.com/api/v10/oauth2/token',['client_id'=>$C['client_id'],'client_secret'=>$C['client_secret'],'grant_type'=>'authorization_code','code'=>$_GET['code'],'redirect_uri'=>$redirect]);
    if(empty($token['access_token']))oauth_error('failed');$user=jget('https://discord.com/api/v10/users/@me',$token['access_token']);
    $providerId=(string)($user['id']??'');$email=strtolower(trim((string)($user['email']??'')));
    if(empty($user['verified'])||!filter_var($email,FILTER_VALIDATE_EMAIL))oauth_error('email');
    $column='did';$display=(string)(($user['global_name']??'')?:($user['username']??'User'));$avatarValue=(string)($user['avatar']??'');
  } else {
    if(empty($C['google_client_id'])||empty($C['google_client_secret']))oauth_error('setup');
    $token=post('https://oauth2.googleapis.com/token',['client_id'=>$C['google_client_id'],'client_secret'=>$C['google_client_secret'],'grant_type'=>'authorization_code','code'=>$_GET['code'],'redirect_uri'=>$redirect]);
    if(empty($token['access_token']))oauth_error('failed');$user=jget('https://www.googleapis.com/oauth2/v3/userinfo',$token['access_token']);
    $providerId=(string)($user['sub']??'');$email=strtolower(trim((string)($user['email']??'')));
    if(empty($user['email_verified'])||!filter_var($email,FILTER_VALIDATE_EMAIL))oauth_error('email');
    $column='gid';$display=(string)($user['name']??strtok($email,'@'));$avatarValue=(string)($user['picture']??'');
  }
  if($providerId==='')oauth_error('failed');
  $q=$db->prepare("SELECT * FROM users WHERE {$column}=? LIMIT 1");$q->execute([$providerId]);$account=$q->fetch(PDO::FETCH_ASSOC);
  if(!$account){
    $q=$db->prepare('SELECT * FROM users WHERE lower(email)=? LIMIT 1');$q->execute([$email]);$account=$q->fetch(PDO::FETCH_ASSOC);
    if($account&&!empty($account[$column])&&$account[$column]!==$providerId)oauth_error('conflict');
    if($account){
      if($provider==='discord'){$db->prepare('UPDATE users SET did=?,dname=?,verified=1 WHERE id=?')->execute([$providerId,$display,$account['id']]);}
      else{$db->prepare('UPDATE users SET gid=?,verified=1 WHERE id=?')->execute([$providerId,$account['id']]);}
    }
  }
  if(!$account){
    $id=$provider==='discord'?$providerId:'g'.bin2hex(random_bytes(8));$name=oauth_name($display);
    $did=$provider==='discord'?$providerId:null;$dname=$provider==='discord'?$display:null;$gid=$provider==='google'?$providerId:null;
    $db->prepare('INSERT INTO users(id,name,avatar,roles,joined,synced,email,verified,did,dname,gid) VALUES(?,?,?,?,?,0,?,1,?,?,?)')->execute([$id,$name,$avatarValue,'[]',time(),$email,$did,$dname,$gid]);
    $q=$db->prepare('SELECT * FROM users WHERE id=?');$q->execute([$id]);$account=$q->fetch(PDO::FETCH_ASSOC);
  } elseif($avatarValue!==''&&empty($account['avatar'])) {
    $db->prepare('UPDATE users SET avatar=? WHERE id=?')->execute([$avatarValue,$account['id']]);$account['avatar']=$avatarValue;
  }
  login_session($account);go(valid_next($saved['next']??'/profile/'));
}
if(isset($_GET['a'])&&in_array($_GET['a'],['discord','google'],true)){
  $provider=$_GET['a'];$base=rtrim((string)($C['site']??'https://nullrtp.dev'),'/');$state=bin2hex(random_bytes(24));
  if($provider==='discord'){
    if(empty($C['client_id'])||empty($C['client_secret']))oauth_error('setup');
    $url='https://discord.com/oauth2/authorize';$params=['client_id'=>$C['client_id'],'redirect_uri'=>$base.'/auth.php?oauth_callback=discord','response_type'=>'code','scope'=>'identify email','state'=>$state,'prompt'=>'consent'];
  }else{
    if(empty($C['google_client_id'])||empty($C['google_client_secret']))oauth_error('setup');
    $url='https://accounts.google.com/o/oauth2/v2/auth';$params=['client_id'=>$C['google_client_id'],'redirect_uri'=>$base.'/auth.php?oauth_callback=google','response_type'=>'code','scope'=>'openid email profile','state'=>$state,'prompt'=>'select_account'];
  }
  $_SESSION['oauth_login']=['provider'=>$provider,'state'=>$state,'next'=>valid_next($_GET['next']??'/profile/'),'time'=>time()];go($url.'?'.http_build_query($params));
}
if(isset($_GET['oauth_callback'])&&in_array($_GET['oauth_callback'],['discord','google'],true))oauth_login($_GET['oauth_callback']);
if(($_GET['a']??'')==='logout'){chk();if(!empty($_SESSION['sid']))$db->prepare('UPDATE sess SET ended=1 WHERE sid=?')->execute([$_SESSION['sid']]);$_SESSION=[];session_destroy();go('/');}
if(isset($_GET['error']))go('/profile/?tab=discord');
if(($_GET['a']??'')==='dlink'){$u=me();if(!$u||empty($C['client_id']))go('/profile/?tab=discord');$_SESSION['dst']=$s=bin2hex(random_bytes(16));go('https://discord.com/oauth2/authorize?'.http_build_query(['client_id'=>$C['client_id'],'redirect_uri'=>$C['site'].'/auth.php','response_type'=>'code','scope'=>'identify','state'=>$s,'prompt'=>'consent']));}
if(isset($_GET['code'])){$u=me();if(!$u||!hash_equals((string)($_SESSION['dst']??'x'),(string)($_GET['state']??'')))go('/profile/?tab=discord&dl=bad');unset($_SESSION['dst']);$tok=post('https://discord.com/api/v10/oauth2/token',['client_id'=>$C['client_id']??'','client_secret'=>$C['client_secret']??'','grant_type'=>'authorization_code','code'=>$_GET['code'],'redirect_uri'=>$C['site'].'/auth.php'])['access_token']??null;
  if($tok){[$code,$d]=dc('GET','/users/@me',$tok);if($code==200&&!empty($d['id'])){$q=$db->prepare('SELECT 1 FROM users WHERE did=? AND id<>?');$q->execute([$d['id'],$u['id']]);if($q->fetch())go('/profile/?tab=discord&dl=taken');$db->prepare('UPDATE users SET did=?,dname=? WHERE id=?')->execute([$d['id'],$d['global_name']?:$d['username'],$u['id']]);go('/profile/?tab=discord&dl=ok');}}
  go('/profile/?tab=discord&dl=fail');}
go('/');
