<?php require __DIR__ . '/app/boot.php'; // вход и регистрация — на страницах /login/ и /register/; здесь только выход
if (($_GET['a'] ?? '') === 'logout') { chk(); if (!empty($_SESSION['sid'])) $db->prepare('UPDATE sess SET ended=1 WHERE sid=?')->execute([$_SESSION['sid']]); $_SESSION = []; session_destroy(); }
if (isset($_GET['error'])) go('/profile/settings/');
if (($_GET['a'] ?? '') === 'dlink') { $u = me(); if (!$u || empty($C['client_id'])) go('/profile/settings/'); $_SESSION['dst'] = $s = bin2hex(random_bytes(16)); // привязка Discord (только identify)
  go('https://discord.com/oauth2/authorize?' . http_build_query(['client_id' => $C['client_id'], 'redirect_uri' => $C['site'] . '/auth.php', 'response_type' => 'code', 'scope' => 'identify', 'state' => $s, 'prompt' => 'consent'])); }
if (isset($_GET['code'])) { $u = me(); if (!$u || !hash_equals((string)($_SESSION['dst'] ?? 'x'), (string)($_GET['state'] ?? ''))) go('/profile/settings/?dl=bad'); unset($_SESSION['dst']);
  $tok = post('https://discord.com/api/v10/oauth2/token', ['client_id' => $C['client_id'] ?? '', 'client_secret' => $C['client_secret'] ?? '', 'grant_type' => 'authorization_code', 'code' => $_GET['code'], 'redirect_uri' => $C['site'] . '/auth.php'])['access_token'] ?? null;
  if ($tok) { [$c, $d] = dc('GET', '/users/@me', $tok);
    if ($c == 200 && !empty($d['id'])) { $q = $db->prepare('SELECT 1 FROM users WHERE did=? AND id<>?'); $q->execute([$d['id'], $u['id']]); if ($q->fetch()) go('/profile/settings/?dl=taken');
      $db->prepare('UPDATE users SET did=?, dname=? WHERE id=?')->execute([$d['id'], $d['global_name'] ?: $d['username'], $u['id']]); go('/profile/settings/?dl=ok'); } }
  go('/profile/settings/?dl=fail'); }
go('/');
