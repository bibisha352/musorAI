<?php require __DIR__ . '/../app/boot.php';
$S = require __DIR__ . '/../app/products.php';
require __DIR__ . '/../app/shop.php'; require __DIR__ . '/../app/pay.php'; $S['items'] = shop_items($S);
function tx($v) { global $L; return is_array($v) ? ($v[$L] ?? reset($v)) : (string)$v; }
$u = me(); $err = ''; $items = $S['items']; $methods = $S['methods'] ?? [];
$i = $_GET['i'] ?? ''; if (is_string($i) && isset($items[$i])) $_SESSION['buy'] = $i;
if (isset($_GET['cancel'])) { unset($_SESSION['buy']); go('/shop/'); }
$sid = $_SESSION['buy'] ?? ''; $sel = (is_string($sid) && isset($items[$sid])) ? $items[$sid] : null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $u && $sel) { chk();
  $m = (string)($_POST['method'] ?? ''); $c = trim((string)($_POST['contact'] ?? ''));
  $q = $db->prepare('SELECT COUNT(*) FROM orders WHERE uid=? AND ts>?'); $q->execute([$u['id'], time() - 600]);
  if (!isset($methods[$m]) || mb_strlen($c) < 3 || mb_strlen($c) > 100) $err = t('e_order');
  elseif ($q->fetchColumn() >= 5) $err = t('e_rate');
  elseif (($sel['stock'] ?? true) === false) $err = t('sold_out');
  else { $k1 = bin2hex(random_bytes(8)); $k2 = bin2hex(random_bytes(8));
    $db->prepare('INSERT INTO orders(k1,k2,uid,item,price,method,contact,ts) VALUES(?,?,?,?,?,?,?,?)')->execute([$k1, $k2, $u['id'], $sid, $S['currency'] . ' ' . $sel['price'], $m, $c, time()]);
    $n = $db->lastInsertId(); unset($_SESSION['buy']);
    $pu = pay_start(['n' => $n, 'k1' => $k1, 'k2' => $k2, 'price' => $S['currency'] . ' ' . $sel['price']], $methods[$m]); // провайдер вернёт ссылку на оплату
    if ($pu['url'] || $pu['pid']) $db->prepare('UPDATE orders SET pid=?, purl=?, cx=? WHERE n=?')->execute([$pu['pid'], $pu['url'], $pu['cx'] ?? '', $n]);
    go($pu['url'] ?: "/shop/order/?a=$k1&b=$k2&n=$n"); } }
$cats = array_values(array_unique(array_column($items, 'cat')));
$cf = (string)($_GET['c'] ?? 'all'); if ($cf === '' || mb_strlen($cf) > 30) $cf = 'all'; if ($cf !== 'all' && !in_array($cf, $cats, true)) $cats[] = $cf; // ?c=CS2 — открыть магазин сразу на нужной категории
top(t('shop'), 'shop'); ?>
<section class="hero c">
  <h1><?= e(t('shop')) ?></h1>
  <p class="lead"><?= e(t('shop_sub')) ?></p>
  <input id="q" class="search" type="search" placeholder="<?= e(t('shop_ph')) ?>" autocomplete="off">
  <div class="cats"><button class="<?= $cf === 'all' ? 'on' : '' ?>" data-c="all" type="button"><?= e(t('all')) ?></button><?php foreach ($cats as $c) echo '<button' . ($c === $cf ? ' class="on"' : '') . ' data-c="' . e($c) . '" type="button">' . e($c) . '</button>'; ?></div>
  <?php if (admin()) echo '<p class="cta" style="justify-content:center"><a class="ghost" href="/shop/manage/">товары</a><a class="ghost" href="/shop/orders/">' . e(t('orders')) . '</a></p>'; ?>
</section>
<div class="grid shop"><?php foreach ($items as $id => $p) { $c = col($p['color'] ?? '') ?: '#2ecc71'; $in = ($p['stock'] ?? true) !== false;
  echo '<article class="card prod"' . ($cf !== 'all' && $p['cat'] !== $cf ? ' hidden' : '') . ' data-c="' . e($p['cat']) . '" data-s="' . e(tx($p['name']) . ' ' . tx($p['desc'] ?? '') . ' ' . $p['cat']) . '" style="--pc:' . $c . '"><div class="pv"><i>' . e($p['icon'] ?? '◆') . '</i>' . (!empty($p['badge']) ? '<span class="bdg">' . e($p['badge']) . '</span>' : '') . '</div><h2>' . e(tx($p['name'])) . '</h2><p>' . e(tx($p['desc'] ?? '')) . '</p><div class="buy"><b>' . e($p['price'] . ' ' . $S['currency']) . (!empty($p['period']) ? ' <small>/ ' . e(tx($p['period'])) . '</small>' : '') . '</b>' . ($in ? '<a class="btn-green" href="/shop/?i=' . e($id) . '#order">' . e(t('buy')) . '</a>' : '<em class="st off">' . e(t('sold_out')) . '</em>') . '</div></article>'; } ?></div>
<?php if ($cf !== 'all' && !array_filter($items, fn($p) => $p['cat'] === $cf)) echo '<p style="text-align:center">' . e(t('empty_shop')) . '</p>'; ?>
<?php if ($sel) { echo '<div id="order"></div>'; if (!$u) logincard('/shop/'); else { ?>
<section class="lcard wide"><h1><?= e(t('checkout')) ?></h1><p><b><?= e(tx($sel['name'])) ?></b> — <?= e($sel['price'] . ' ' . $S['currency']) ?></p>
  <form method="post" class="tform"><input type="hidden" name="t" value="<?= csrf() ?>">
    <label><?= e(t('contact')) ?></label><input name="contact" maxlength="100" required value="<?= e(ctype_digit($u['id']) ? $u['id'] : '') ?>">
    <label><?= e(t('pay_method')) ?></label>
    <div class="pills"><?php foreach ($methods as $k => $m) echo '<label><input type="radio" name="method" value="' . e($k) . '"' . ($k === array_key_first($methods) ? ' checked' : '') . '><span>' . e(tx($m['name'])) . '</span></label>'; ?></div>
    <?php if ($err) echo '<p class="err">' . e($err) . '</p>'; ?>
    <div class="pact" style="margin-top:0"><button class="btn-green" type="submit"><?= e(t('go_pay')) ?></button><a class="ghost" href="/shop/?cancel=1"><?= e(t('cancel')) ?></a></div>
  </form></section>
<?php } } bottom();
