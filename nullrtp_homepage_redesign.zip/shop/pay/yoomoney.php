<?php require __DIR__ . '/../../app/boot.php'; // HTTP-уведомления ЮMoney: адрес в настройках кошелька https://nullrtp.dev/shop/pay/yoomoney.php
$P = $C['pay']['yoomoney'] ?? []; $s = '';
foreach (['notification_type', 'operation_id', 'amount', 'currency', 'datetime', 'sender', 'codepro'] as $k) $s .= ($_POST[$k] ?? '') . '&';
$s .= ($P['secret'] ?? '') . '&' . ($_POST['label'] ?? '');
if (!empty($P['secret']) && hash_equals(sha1($s), strtolower((string)($_POST['sha1_hash'] ?? ''))) && ($_POST['codepro'] ?? '') === 'false') {
  $q = $db->prepare('SELECT * FROM orders WHERE n=?'); $q->execute([(int)($_POST['label'] ?? 0)]); $o = $q->fetch(PDO::FETCH_ASSOC);
  $paid = (float)($_POST['withdraw_amount'] ?? $_POST['amount'] ?? 0);
  if ($o && in_array($o['status'], ['new', 'paid'], true) && strtoupper(strtok($o['price'], ' ')) === 'RUB' && $paid >= (float)trim(substr(strstr($o['price'], ' '), 1)) * 0.95) $db->prepare("UPDATE orders SET status='ok' WHERE n=?")->execute([$o['n']]); }
http_response_code(200);
