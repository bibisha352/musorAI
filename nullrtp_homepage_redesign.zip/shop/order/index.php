<?php require __DIR__ . '/../../app/boot.php';
$S = require __DIR__ . '/../../app/products.php';
require __DIR__ . '/../../app/shop.php'; require __DIR__ . '/../../app/pay.php'; $S['items'] = shop_items($S);
function tx($v) { global $L; return is_array($v) ? ($v[$L] ?? reset($v)) : (string)$v; }
$u = me(); if (!$u) go('/login/');
$q = $db->prepare('SELECT * FROM orders WHERE n=? AND k1=? AND k2=?'); $q->execute([(int)($_GET['n'] ?? 0), (string)($_GET['a'] ?? ''), (string)($_GET['b'] ?? '')]);
$o = $q->fetch(PDO::FETCH_ASSOC); $mine = $o && $o['uid'] === $u['id']; $adm = admin();
if (!$o || (!$mine && !$adm)) { http_response_code(404); readfile(__DIR__ . '/../../404.html'); exit; }
$url = "/shop/order/?a={$o['k1']}&b={$o['k2']}&n={$o['n']}";
if ($_SERVER['REQUEST_METHOD'] === 'POST') { chk(); $a = $_POST['act'] ?? ''; $st = null;
  if ($mine && $o['status'] === 'new' && $a === 'paid') $st = 'paid';
  elseif ($mine && $o['status'] === 'new' && $a === 'cancelled') $st = 'cancelled';
  elseif ($adm && in_array($a, ['done', 'cancelled', 'paid', 'new', 'ok'], true)) $st = $a;
  if ($st) $db->prepare('UPDATE orders SET status=? WHERE n=?')->execute([$st, $o['n']]);
  go($url); }
$it = $S['items'][$o['item']] ?? null; $m = $S['methods'][$o['method']] ?? null; $info = $m ? tx($m['info'] ?? '') : ''; $ty = $m['type'] ?? 'manual'; $cx = json_decode((string)($o['cx'] ?? ''), true);
if ($o['status'] === 'new' && $m && pay_check($o, $m)) { $db->prepare("UPDATE orders SET status='ok' WHERE n=?")->execute([$o['n']]); $o['status'] = 'ok'; } // оплата подтверждена платёжной системой
function act($url, $a, $label, $cls = 'ghost') { return '<form method="post" action="' . e($url) . '"><input type="hidden" name="t" value="' . csrf() . '"><input type="hidden" name="act" value="' . $a . '"><button class="' . $cls . '" type="submit">' . e($label) . '</button></form>'; }
top(t('order') . ' #' . $o['n'], 'shop'); ?>
<section class="lcard wide">
  <h1><?= e($it ? tx($it['name']) : $o['item']) ?></h1>
  <div class="tk-h"><span class="role">#<?= (int)$o['n'] ?></span><span class="role"><?= e($o['price']) ?></span><span class="role"><?= e($m ? tx($m['name']) : $o['method']) ?></span><span class="role alt"><?= e(t('os_' . $o['status'])) ?></span><span class="role alt"><?= e(date('d M Y, H:i', (int)$o['ts'])) ?></span></div>
  <p style="margin-top:18px"><?= e(t('contact')) ?>: <b><?= e($o['contact']) ?></b></p>
  <?php if (in_array($o['status'], ['new', 'paid'], true) && ($info || $ty === 'manual' || $ty === 'link' || ($ty === 'crypto' && !$cx))) echo '<div class="msg staff" style="max-width:100%"><small>' . e(t('pay_info')) . '</small>' . e($info ?: t('no_info')) . '</div>'; ?>
  <?php if ($cx && $o['status'] === 'new') echo '<div class="msg staff" style="max-width:100%"><small>' . e(t('pay_info')) . ' · ' . e($cx['coin']) . '</small>' . e(t('cx_send')) . ' <b>' . e($cx['amt']) . ' ' . e($cx['coin']) . '</b> ' . e(t('cx_to')) . '<br><code style="word-break:break-all">' . e($cx['addr']) . '</code>' . ($cx['memo'] ? '<br>' . e(t('cx_memo')) . ': <code>' . e($cx['memo']) . '</code>' : '') . '<br><small>' . e(t('cx_hint')) . '</small></div>'; ?>
  <div class="pact"><?php if ($mine && $o['status'] === 'new') {
      if ($o['purl']) echo '<a class="btn-green" href="' . e($o['purl']) . '">' . e(t('pay_now')) . '</a>';
      if ($o['pid'] && $o['pid'] !== 'ym') echo '<a class="ghost" href="' . e($url) . '">' . e(t('check_pay')) . '</a>';
      if ($ty === 'manual' || $ty === 'link') echo act($url, 'paid', t('i_paid'), $o['purl'] ? 'ghost' : 'btn-green');
      echo act($url, 'cancelled', t('cancel')); } ?>
    <a class="ghost" href="/support/new/"><?= e(t('order_help')) ?></a></div>
  <?php if ($adm) echo '<div class="pact">' . act($url, 'done', t('mark_done'), 'btn-green') . act($url, 'ok', t('os_ok')) . act($url, 'cancelled', t('os_cancelled')) . act($url, 'new', t('os_new')) . '</div>'; ?>
</section>
<?php bottom();
