<?php require __DIR__ . '/../../app/boot.php';
$adminHost = strtolower(preg_replace('/:\\d+$/', '', (string)($_SERVER['HTTP_HOST'] ?? ''))) === 'admin.nullrtp.dev';
if (!$adminHost) { header('Location: https://admin.nullrtp.dev/shop/', true, 302); exit; }
 require __DIR__ . '/../../app/shop.php';
$S = require __DIR__ . '/../../app/products.php';
if (!admin()) { http_response_code(404); readfile(__DIR__ . '/../../404.html'); exit; } // товары выставляет только админ
$items = shop_items($S); $err = ''; $LG = ['ru', 'ua', 'en'];
if ($_SERVER['REQUEST_METHOD'] === 'POST') { chk(); $a = $_POST['act'] ?? ''; $id = strtolower(trim((string)($_POST['id'] ?? '')));
  if ($a === 'del') $db->prepare('DELETE FROM items WHERE id=?')->execute([$id]);
  elseif ($a === 'stock') $db->prepare('UPDATE items SET stock=1-stock WHERE id=?')->execute([$id]);
  elseif ($a === 'save') { $pr = trim((string)($_POST['price'] ?? ''));
    $js = function ($k, $max) use ($LG) { $o = []; foreach ($LG as $l) $o[$l] = mb_substr(trim((string)($_POST[$k . '_' . $l] ?? '')), 0, $max); return json_encode($o, JSON_UNESCAPED_UNICODE); };
    if (!preg_match('/^[a-z0-9-]{2,40}$/', $id) || !preg_match('/^\d{1,7}(\.\d{1,2})?$/', $pr) || mb_strlen(trim((string)($_POST['name_ru'] ?? ''))) < 2) $err = 'Проверь: id (a-z, 0-9, дефис), цена числом, название (RU) обязательно.';
    else { $db->prepare('INSERT INTO items(id,cat,icon,color,badge,price,period,stock,name,descr,ts) VALUES(?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET cat=excluded.cat,icon=excluded.icon,color=excluded.color,badge=excluded.badge,price=excluded.price,period=excluded.period,stock=excluded.stock,name=excluded.name,descr=excluded.descr')
      ->execute([$id, mb_substr(trim((string)($_POST['cat'] ?? '')), 0, 30), mb_substr(trim((string)($_POST['icon'] ?? '')) ?: '◆', 0, 2), col($_POST['color'] ?? '') ?: '#2ecc71', mb_substr(trim((string)($_POST['badge'] ?? '')), 0, 20), $pr, $js('period', 20), empty($_POST['stock']) ? 0 : 1, $js('name', 80), $js('desc', 400), time()]); } }
  if (!$err) go('/shop/'); $items = shop_items($S); }
$eid = (string)($_GET['e'] ?? ''); $ed = $items[$eid] ?? null; $v = fn($k, $d = '') => e($ed[$k] ?? $d); $ml = fn($k, $l) => e($ed[$k][$l] ?? '');
function aform($a, $id, $label, $cls = 'ghost') { return '<form method="post"><input type="hidden" name="t" value="' . csrf() . '"><input type="hidden" name="act" value="' . $a . '"><input type="hidden" name="id" value="' . e($id) . '"><button class="' . $cls . '" type="submit">' . $label . '</button></form>'; }
top('товары', 'shop'); ?>
<section class="lcard wide"><h1>товары магазина</h1>
<div class="tlist"><?php foreach ($items as $id => $p) echo '<div class="trow dev"><span><b>' . e($p['name']['ru'] ?? reset($p['name'])) . '</b><br><small>' . e($id) . ' · ' . e($p['price']) . ' · ' . e($p['cat']) . '</small></span><em class="st' . ($p['stock'] ? '' : ' off') . '">' . ($p['stock'] ? 'в наличии' : 'нет') . '</em><a class="ghost" href="/shop/manage/?e=' . e($id) . '#form">изменить</a>' . aform('stock', $id, 'наличие') . aform('del', $id, 'удалить') . '</div>'; if (!$items) echo '<p>товаров нет — добавь первый ниже</p>'; ?></div></section>
<section class="lcard wide" id="form"><h1><?= $ed ? 'изменить товар' : 'новый товар' ?></h1>
  <form method="post" class="tform"><input type="hidden" name="t" value="<?= csrf() ?>"><input type="hidden" name="act" value="save">
    <label>id (a-z, 0-9, дефис; не меняется)</label><input name="id" maxlength="40" required value="<?= e($eid && $ed ? $eid : '') ?>" <?= $ed ? 'readonly' : '' ?>>
    <?php foreach (['name' => ['название', 80], 'desc' => ['описание', 400], 'period' => ['период (например: мес)', 20]] as $k => [$lb, $mx]) foreach ($LG as $l) echo '<label>' . $lb . ' · ' . strtoupper($l) . ($k === 'name' && $l === 'ru' ? ' *' : '') . '</label>' . ($k === 'desc' ? '<textarea name="' . $k . '_' . $l . '" rows="2" maxlength="' . $mx . '">' . $ml($k, $l) . '</textarea>' : '<input name="' . $k . '_' . $l . '" maxlength="' . $mx . '" value="' . $ml($k, $l) . '">'); ?>
    <label>цена (число) *</label><input name="price" maxlength="10" required value="<?= $v('price') ?>">
    <label>категория (кнопка фильтра)</label><input name="cat" maxlength="30" value="<?= $v('cat') ?>">
    <label>значок (1–2 символа)</label><input name="icon" maxlength="2" value="<?= $v('icon', '◆') ?>">
    <label>цвет</label><input type="color" name="color" value="<?= e(col($ed['color'] ?? '') ?: '#2ecc71') ?>">
    <label>метка (new, hot, VIP…)</label><input name="badge" maxlength="20" value="<?= $v('badge') ?>">
    <label><input type="checkbox" name="stock" value="1" <?= !$ed || $ed['stock'] ? 'checked' : '' ?>> в наличии</label>
    <?php if ($err) echo '<p class="err">' . e($err) . '</p>'; ?>
    <div class="pact" style="margin-top:0"><button class="btn-green" type="submit">сохранить</button><a class="ghost" href="/shop/"><?= e(t('back')) ?></a></div>
  </form></section>
<?php bottom();
