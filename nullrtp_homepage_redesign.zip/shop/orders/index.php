<?php require __DIR__ . '/../../app/boot.php';
$S = require __DIR__ . '/../../app/products.php';
require __DIR__ . '/../../app/shop.php'; $S['items'] = shop_items($S);
function tx($v) { global $L; return is_array($v) ? ($v[$L] ?? reset($v)) : (string)$v; }
if (!admin()) { http_response_code(404); readfile(__DIR__ . '/../../404.html'); exit; }
$rows = $db->query('SELECT o.*, u.name FROM orders o LEFT JOIN users u ON u.id=o.uid ORDER BY o.n DESC LIMIT 300')->fetchAll(PDO::FETCH_ASSOC);
top(t('orders'), 'shop'); ?>
<section class="lcard wide"><h1><?= e(t('orders')) ?></h1><div class="tlist"><?php foreach ($rows as $r) { $it = $S['items'][$r['item']] ?? null;
  echo '<a class="trow" href="/shop/order/?a=' . $r['k1'] . '&amp;b=' . $r['k2'] . '&amp;n=' . $r['n'] . '"><b>#' . (int)$r['n'] . '</b><span>' . e($it ? tx($it['name']) : $r['item']) . ' <small>· ' . e($r['name'] ?? '?') . ' · ' . e($r['price']) . '</small></span><em class="st">' . e(t('os_' . $r['status'])) . '</em><small>' . e(date('d M H:i', (int)$r['ts'])) . '</small></a>'; } if (!$rows) echo '<p>—</p>'; ?></div>
<div class="pact"><a class="ghost" href="/shop/"><?= e(t('back')) ?></a></div></section>
<?php bottom();
