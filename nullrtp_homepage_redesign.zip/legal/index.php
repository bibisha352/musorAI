<?php require __DIR__ . '/../app/boot.php';
$p = $_GET['p'] ?? '';
if (!in_array($p, ['about', 'terms', 'privacy', 'cookies', 'rules'], true)) { http_response_code(404); readfile(__DIR__ . '/../404.html'); exit; }
top(t('f_' . $p)); echo '<article class="doc"><h1>' . e(t('f_' . $p)) . '</h1><p>' . nl2br(e(file_get_contents(is_file($f = __DIR__ . "/$p.$L.txt") ? $f : __DIR__ . "/$p.txt"))) . '</p></article>'; bottom();
