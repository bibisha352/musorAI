<?php require __DIR__ . '/../app/boot.php'; // ссылка из письма: /reset/?token=...  (действует 1 час)
$tk = (string)($_GET['token'] ?? $_POST['token'] ?? ''); $u = null; $ok = false; $err = '';
if (preg_match('/^[a-f0-9]{32}$/', $tk)) { $q = $db->prepare('SELECT * FROM users WHERE rst=? AND rsts>?'); $q->execute([hash('sha256', $tk), time() - 3600]); $u = $q->fetch(PDO::FETCH_ASSOC) ?: null; }
if ($u && $_SERVER['REQUEST_METHOD'] === 'POST') { $pw = (string)($_POST['pass'] ?? '');
  if (strlen($pw) < 8 || strlen($pw) > 72) $err = t('e_pass');
  else { $db->prepare('UPDATE users SET pass=?, rst=NULL, verified=1 WHERE id=?')->execute([password_hash($pw, PASSWORD_DEFAULT), $u['id']]); $ok = true; } }
top(t('forgot')); plogo(); ?>
<section class="lcard modal">
<?php if ($ok) echo '<p style="margin:0 0 14px;color:#e8eaee">' . e(t('pass_ok')) . '</p><p class="mlinks"><a href="/login/">' . e(t('login')) . '</a></p>';
elseif (!$u) echo '<p style="margin:0 0 14px;color:#e8eaee">' . e(t('conf_bad')) . '</p><p class="mlinks"><a href="/forgot/">' . e(t('forgot')) . '</a></p>';
else { ?><form method="post" class="tform mf"><input type="hidden" name="token" value="<?= e($tk) ?>"><input type="password" name="pass" placeholder="<?= e(t('new_pass')) ?>" required maxlength="72" autocomplete="new-password"><?php if ($err) echo '<p class="err">' . e($err) . '</p>'; ?><button class="btn-green wide" type="submit"><?= e(t('save')) ?></button></form><?php } ?></section>
<?php bottom();
