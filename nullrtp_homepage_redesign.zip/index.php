<?php
require __DIR__ . '/app/boot.php';

$TR += [
  'h_eyebrow' => 'НЕЗАВИСИМОЕ СООБЩЕСТВО|НЕЗАЛЕЖНА СПІЛЬНОТА|INDEPENDENT COMMUNITY',
  'h_sub' => 'Единое пространство для общения, идей и новых знакомств. Создай профиль, находи единомышленников и будь в центре событий.|Єдиний простір для спілкування, ідей та нових знайомств. Створи профіль, знаходь однодумців і будь у центрі подій.|One place for conversations, ideas and new connections. Create a profile, meet like-minded people and stay in the loop.',
  'h_btn' => 'исследовать платформу|дослідити платформу|explore the platform',
  'h_forum_btn' => 'открыть сообщество|відкрити спільноту|open community',
  'h_online' => 'все системы работают|усі системи працюють|all systems operational',
  'h_module_kicker' => '01 / ПРОСТРАНСТВО|01 / ПРОСТІР|01 / THE SPACE',
  'h_module_title' => 'Всё начинается здесь.|Усе починається тут.|Everything starts here.',
  'h_module_sub' => 'Три простых способа стать частью nullrtp.|Три прості способи стати частиною nullrtp.|Three simple ways to become part of nullrtp.',
  'h_mod_forum' => 'Сообщество|Спільнота|Community',
  'h_mod_forum_d' => 'Обсуждай, делись идеями, задавай вопросы и находи людей на одной волне.|Обговорюй, ділися ідеями, став запитання та знаходь людей на одній хвилі.|Share ideas, ask questions and connect with people who get you.',
  'h_mod_profile' => 'Твой профиль|Твій профіль|Your profile',
  'h_mod_profile_d' => 'Создай свой уголок: настрой профиль и собери всё важное в одном месте.|Створи власний простір: налаштуй профіль і збери все важливе в одному місці.|Make it yours: personalise your profile and keep everything together.',
  'h_mod_support' => 'Центр поддержки|Центр підтримки|Support centre',
  'h_mod_support_d' => 'Нужна помощь или есть идея? Напиши нам — разберёмся вместе.|Потрібна допомога чи маєш ідею? Напиши нам — розберемося разом.|Need a hand or have an idea? Reach out and we will figure it out together.',
  'h_open' => 'перейти|перейти|explore',
  'h_features_kicker' => '02 / ПОЧЕМУ NULLRTP|02 / ЧОМУ NULLRTP|02 / WHY NULLRTP',
  'h_features_title' => 'Меньше шума. Больше возможностей.|Менше шуму. Більше можливостей.|Less noise. More possibility.',
  'h_features_sub' => 'Продуманные детали, которые делают пребывание в сообществе удобнее.|Продумані деталі, що роблять перебування у спільноті зручнішим.|Thoughtful details that make being part of the community feel effortless.',
  'f1t' => 'Всё под рукой|Усе під рукою|Everything in one place',
  'f1d' => 'Профиль, форум и поддержка доступны из одного пространства.|Профіль, форум і підтримка доступні в одному просторі.|Your profile, forum and support are all part of one space.',
  'f2t' => 'Живое сообщество|Жива спільнота|A living community',
  'f2d' => 'Обсуждения, полезные материалы и люди, с которыми есть о чём поговорить.|Обговорення, корисні матеріали та люди, з якими є про що поговорити.|Conversations, useful resources and people worth talking to.',
  'f3t' => 'Настоящая поддержка|Справжня підтримка|Human support',
  'f3d' => 'Тикеты с ответами в одном месте. Мы поможем разобраться.|Тікети з відповідями в одному місці. Ми допоможемо розібратися.|Replies stay in one place, so it is easier to get help.',
  'f4t' => 'Твой стиль|Твій стиль|Make it yours',
  'f4d' => 'Аватар, баннер, роли и настройки — профиль можно настроить под себя.|Аватар, банер, ролі й налаштування — профіль можна зробити своїм.|Avatar, banner, roles and settings let your profile feel personal.',
  'f5t' => 'Открытость идеям|Відкритість до ідей|Open to ideas',
  'f5d' => 'Предложения и обратная связь помогают сообществу становиться лучше.|Пропозиції та відгуки допомагають спільноті ставати кращою.|Suggestions and feedback help the community keep improving.',
  'f6t' => 'Три языка|Три мови|Three languages',
  'f6d' => 'Понятный интерфейс на русском, украинском и английском.|Зрозумілий інтерфейс українською, російською та англійською.|A clear interface in English, Russian and Ukrainian.',
  'h_cta_kicker' => '03 / ТВОЙ ХОД|03 / ТВОЯ ЧЕРГА|03 / YOUR MOVE',
  'h_cta_title' => 'Твоя история начинается здесь.|Твоя історія починається тут.|Your story starts here.',
  'h_cta_sub' => 'Присоединяйся к nullrtp — впереди много интересного.|Приєднуйся до nullrtp — попереду багато цікавого.|Join nullrtp. There is a lot more ahead.',
  'h_cta_btn' => 'создать аккаунт|створити акаунт|create an account',
];

top('home', 'home', true);
?>

<section class="hhero" id="top">
  <div class="hero-grid" aria-hidden="true"></div>
  <div class="hero-glow hero-glow-one" aria-hidden="true"></div>
  <div class="hero-glow hero-glow-two" aria-hidden="true"></div>

  <div class="hero-copy">
    <div class="home-kicker home-reveal">
      <span class="live-dot"></span>
      <span><?= e(t('h_eyebrow')) ?></span>
      <i>EST. 2026</i>
    </div>

    <div class="hero-heading home-reveal">
      <p class="hero-pretitle">A DIGITAL SPACE FOR PEOPLE</p>
      <h1 class="hh1">NULLRTP<span>.DEV</span></h1>
    </div>

    <p class="hsub home-reveal"><?= e(t('h_sub')) ?></p>

    <div class="hero-actions home-reveal">
      <a class="btn-green big" href="#platform"><span><?= e(t('h_btn')) ?></span><b aria-hidden="true">↘</b></a>
      <a class="hero-secondary" href="/forum/"><span class="secondary-icon" aria-hidden="true">↗</span><?= e(t('h_forum_btn')) ?></a>
    </div>

    <div class="hero-foot home-reveal">
      <div class="hero-foot-item"><span class="foot-index">01</span><span>COMMUNITY<br><b>FIRST</b></span></div>
      <div class="hero-foot-item"><span class="foot-index">02</span><span>BUILT FOR<br><b>PEOPLE</b></span></div>
      <div class="hero-foot-item"><span class="foot-index">03</span><span>ALWAYS<br><b>EVOLVING</b></span></div>
    </div>
  </div>

  <div class="hero-visual home-reveal" aria-label="nullrtp system status">
    <div class="orbit-field" aria-hidden="true">
      <span class="orbit-ring orbit-ring-a"></span>
      <span class="orbit-ring orbit-ring-b"></span>
      <span class="orbit-ring orbit-ring-c"></span>
      <span class="orbit-node orbit-node-a"></span>
      <span class="orbit-node orbit-node-b"></span>
      <span class="orbit-node orbit-node-c"></span>
    </div>

    <div class="hero-float hero-float-top"><span class="float-ping"></span><span>NETWORK</span><b>CONNECTED</b></div>
    <div class="hero-console">
      <div class="console-chrome">
        <div class="console-dots"><i></i><i></i><i></i></div>
        <span class="console-window">nullrtp://system</span>
        <span class="console-version">v.01</span>
      </div>

      <div class="console-content">
        <div class="console-brandline">
          <div class="console-brand-icon"><img src="/assets/img/favicon.svg" alt=""></div>
          <div><b>NULLRTP</b><small>COMMUNITY CORE</small></div>
          <span class="console-state"><i></i> LIVE</span>
        </div>

        <div class="console-status">
          <div><small>SYSTEM STATUS</small><b><?= e(t('h_online')) ?></b></div>
          <span class="status-check">✓</span>
        </div>

        <div class="term" aria-label="system log">
          <div><b>01</b> root@nullrtp:~ $ init community</div>
          <div><b>02</b> loading modules and connections...</div>
          <div><b>03</b> secure channel established</div>
          <div><b>04</b> gateway status: online</div>
        </div>

        <div class="console-graph-head"><span>NETWORK ACTIVITY</span><span>LIVE / 24H</span></div>
        <div class="console-graph" aria-hidden="true">
          <?php foreach ([24,38,31,52,42,66,46,58,34,72,49,61,40,78,55,68,45,83,59,70,47,64,36,75,51,88,57,73] as $i => $h): ?>
            <i style="--h:<?= (int)$h ?>%;--i:<?= (int)$i ?>"></i>
          <?php endforeach; ?>
        </div>
      </div>

      <div class="console-bottom"><span><i></i> <?= e(t('h_online')) ?></span><span>SYS.NODE / 001</span></div>
    </div>

    <div class="hero-float hero-float-bottom"><span class="float-spark">✳</span><div><small>MADE FOR</small><b>THE COMMUNITY</b></div></div>
  </div>

  <a class="hero-scroll" href="#platform" aria-label="Scroll to platform"><span>SCROLL TO EXPLORE</span><i></i></a>
</section>

<div class="signal-strip" aria-hidden="true">
  <div class="signal-track">
    <?php for ($n = 0; $n < 2; $n++): ?>
      <span>COMMUNITY</span><i>✳</i><span>IDEAS</span><i>✳</i><span>PEOPLE</span><i>✳</i><span>CONNECTION</span><i>✳</i><span>SUPPORT</span><i>✳</i><span>BUILT TOGETHER</span><i>✳</i>
    <?php endfor; ?>
  </div>
</div>

<section class="module-section" id="platform">
  <div class="section-head home-reveal">
    <div>
      <p class="section-kicker"><?= e(t('h_module_kicker')) ?></p>
      <h2><?= e(t('h_module_title')) ?></h2>
      <p class="section-description"><?= e(t('h_module_sub')) ?></p>
    </div>
    <span class="section-counter">03 <i>/</i> MODULES</span>
  </div>

  <div class="module-grid">
    <a class="module-card module-community home-reveal" href="/forum/">
      <div class="module-visual">
        <span class="module-number">01 / COMMUNITY</span>
        <span class="module-glyph glyph-community" aria-hidden="true">◈</span>
        <span class="module-orbit" aria-hidden="true"></span>
        <span class="module-route">/forum/</span>
      </div>
      <div class="module-copy">
        <div><h3><?= e(t('h_mod_forum')) ?></h3><p><?= e(t('h_mod_forum_d')) ?></p></div>
        <span class="module-open" aria-label="<?= e(t('h_open')) ?>">↗</span>
      </div>
    </a>

    <a class="module-card module-profile home-reveal" href="/register/">
      <div class="module-visual">
        <span class="module-number">02 / IDENTITY</span>
        <span class="module-glyph glyph-profile" aria-hidden="true">◎</span>
        <span class="module-orbit" aria-hidden="true"></span>
        <span class="module-route">/profile/</span>
      </div>
      <div class="module-copy">
        <div><h3><?= e(t('h_mod_profile')) ?></h3><p><?= e(t('h_mod_profile_d')) ?></p></div>
        <span class="module-open" aria-label="<?= e(t('h_open')) ?>">↗</span>
      </div>
    </a>

    <a class="module-card module-support home-reveal" href="/support/">
      <div class="module-visual">
        <span class="module-number">03 / SUPPORT</span>
        <span class="module-glyph glyph-support" aria-hidden="true">⌁</span>
        <span class="module-orbit" aria-hidden="true"></span>
        <span class="module-route">/support/</span>
      </div>
      <div class="module-copy">
        <div><h3><?= e(t('h_mod_support')) ?></h3><p><?= e(t('h_mod_support_d')) ?></p></div>
        <span class="module-open" aria-label="<?= e(t('h_open')) ?>">↗</span>
      </div>
    </a>
  </div>
</section>

<section class="feature-section" id="about">
  <div class="section-head feature-heading home-reveal">
    <div>
      <p class="section-kicker"><?= e(t('h_features_kicker')) ?></p>
      <h2><?= e(t('h_features_title')) ?></h2>
      <p class="section-description"><?= e(t('h_features_sub')) ?></p>
    </div>
    <span class="feature-stamp" aria-hidden="true">N<span>/</span>R</span>
  </div>

  <div class="feature-grid">
    <?php foreach (['✳', '◈', '⌁', '◎', '↗', '⌘'] as $i => $symbol): $n = $i + 1; ?>
      <article class="feature-card home-reveal">
        <div class="feature-card-top"><span>0<?= $n ?></span><i aria-hidden="true"><?= $symbol ?></i></div>
        <h3><?= e(t("f{$n}t")) ?></h3>
        <p><?= e(t("f{$n}d")) ?></p>
        <span class="feature-line" aria-hidden="true"></span>
      </article>
    <?php endforeach; ?>
  </div>
</section>

<section class="home-cta home-reveal">
  <div class="cta-orb cta-orb-a" aria-hidden="true"></div>
  <div class="cta-orb cta-orb-b" aria-hidden="true"></div>
  <div class="cta-inner">
    <p class="section-kicker"><?= e(t('h_cta_kicker')) ?></p>
    <h2><?= e(t('h_cta_title')) ?></h2>
    <p><?= e(t('h_cta_sub')) ?></p>
    <div class="cta-actions">
      <a class="btn-green big" href="/register/"><span><?= e(t('h_cta_btn')) ?></span><b aria-hidden="true">↗</b></a>
      <a class="hero-secondary" href="/forum/"><span class="secondary-icon" aria-hidden="true">↗</span><?= e(t('h_forum_btn')) ?></a>
    </div>
  </div>
  <div class="cta-watermark" aria-hidden="true">NULLRTP</div>
</section>

<?php bottom(); ?>
