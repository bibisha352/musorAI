<?php
require __DIR__ . '/app/boot.php';
$host = strtolower(preg_replace('/:\\d+$/', '', (string)($_SERVER['HTTP_HOST'] ?? '')));
if ($host === 'admin.nullrtp.dev') { require __DIR__ . '/admin/index.php'; exit; }
$copy = [
 'ru'=>['tag'=>'ПЛАТФОРМА ПРОЕКТОВ','line'=>'Проекты. Инструменты. Разработка.','open'=>'ОТКРЫТЬ NULLCORE','forum'=>'ФОРУМ','state'=>'ВСЕ СИСТЕМЫ РАБОТАЮТ','log'=>['инициализация nullrtp','загрузка модулей проекта','защищённое соединение активно','версия интерфейса: v0.2']],
 'ua'=>['tag'=>'ПЛАТФОРМА ПРОЄКТІВ','line'=>'Проєкти. Інструменти. Розробка.','open'=>'ВІДКРИТИ NULLCORE','forum'=>'ФОРУМ','state'=>'УСІ СИСТЕМИ ПРАЦЮЮТЬ','log'=>['ініціалізація nullrtp','завантаження модулів проєкту','захищене з’єднання активне','версія інтерфейсу: v0.2']],
 'en'=>['tag'=>'PROJECT PLATFORM','line'=>'Projects. Tools. Development.','open'=>'OPEN NULLCORE','forum'=>'FORUM','state'=>'ALL SYSTEMS OPERATIONAL','log'=>['initialising nullrtp','loading project modules','secure connection active','interface version: v0.2']]
]; $c=$copy[$L]??$copy['ru']; top('nullrtp.dev','home',true);
?>
<section class="v02-hero"><div class="v02-grid" aria-hidden="true"></div><div class="v02-glow v02-glow-a" aria-hidden="true"></div><div class="v02-glow v02-glow-b" aria-hidden="true"></div>
<div class="v02-copy"><div class="v02-kicker"><i></i><?= e($c['tag']) ?><span>EST. 2026</span></div><p class="v02-overline">DIGITAL PROJECTS / NULL PLATFORM</p><h1 class="v02-title">NULLRTP<span>.DEV</span></h1><p class="v02-sub"><?= e($c['line']) ?></p>
<div class="v02-actions"><a class="btn-green big" href="/nullcore/"><?= e($c['open']) ?><b>↗</b></a><a class="v02-secondary" href="/forum/"><?= e($c['forum']) ?> <span>↗</span></a></div><div class="v02-meta"><span>01 / PROJECTS</span><span>02 / TOOLS</span><span>03 / DEVELOPMENT</span></div></div>
<div class="v02-console"><div class="v02-console-head"><span><i></i><i></i><i></i></span><b>nullrtp://system</b><em>v0.2</em></div><div class="v02-console-brand"><img src="/assets/img/favicon.svg" alt=""><span><b>NULLRTP</b><small>PROJECT SYSTEM</small></span><i>ONLINE</i></div>
<div class="v02-status"><small>SYSTEM STATUS</small><b><?= e($c['state']) ?></b><span>✓</span></div><div class="v02-terminal"><?php foreach($c['log'] as $i=>$line): ?><p><b>0<?= $i+1 ?></b><span><?= e($line) ?></span></p><?php endforeach; ?></div><div class="v02-console-foot"><span><i></i> SECURE CONNECTION</span><span>BUILD / 0.2</span></div></div>
<a class="v02-scroll" href="#projects"><span>SCROLL TO PROJECTS</span><i></i></a></section>
<section class="v02-projects" id="projects"><div class="v02-section-head"><span>PROJECT INDEX / 001</span><span>NULLRTP.DEV</span></div><div class="v02-project-grid">
<a class="v02-project" href="/nullcore/"><small>01 / DISCORD</small><b>NULLCORE</b><span>Модификация клиента Discord на основе Vencord</span><i>↗</i></a>
<a class="v02-project" href="/lua/"><small>02 / GAME TOOLS</small><b>NULLRTP LUA</b><span>Раздел Lua-проектов</span><i>↗</i></a>
<a class="v02-project" href="/shop/"><small>03 / STORE</small><b>SHOP</b><span>Магазин проекта</span><i>↗</i></a>
</div></section>
<?php bottom(); ?>
