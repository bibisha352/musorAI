<?php // МАГАЗИН — редактируй этот файл. Товары и способы оплаты (первые три товара взяты с твоей прежней страницы).
// У каждого товара свой короткий id (латиница, цифры, дефис). Чтобы добавить товар — скопируй блок и поменяй id.
// cat — категория (кнопка фильтра), icon — символ, color — цвет, badge — метка, period — «в мес» (можно убрать), stock => false — нет в наличии.
// name/desc/period/info можно писать строкой или массивом ['ru' => ..., 'ua' => ..., 'en' => ...].
return [
  'currency' => 'RUB',
  'methods' => [ // порядок = порядок на сайте. type: yookassa (карты/СБП), stripe, paypal — платёжка сама ведёт на оплату и подтверждает её;
    // crypto — автопроверка по блокчейну (coin: USDT/BTC/TON/SOL, addr — ТВОЙ адрес кошелька); manual — реквизиты в 'info', подтверждает админ.
    'sbp' => ['name' => 'СБП', 'type' => 'yookassa', 'pm' => 'sbp'],
    'card' => ['name' => 'Карты Мир/Visa/MC', 'type' => 'yookassa', 'pm' => 'bank_card'],
    'stripe' => ['name' => 'Stripe', 'type' => 'stripe'],
    'paypal' => ['name' => 'PayPal', 'type' => 'paypal'],
    'usdt' => ['name' => 'USDT (TRC-20)', 'type' => 'crypto', 'coin' => 'USDT', 'addr' => ''],
    'btc' => ['name' => 'Bitcoin (BTC)', 'type' => 'crypto', 'coin' => 'BTC', 'addr' => ''],
    'ton' => ['name' => 'TON', 'type' => 'crypto', 'coin' => 'TON', 'addr' => ''],
    'sol' => ['name' => 'Solana (SOL)', 'type' => 'crypto', 'coin' => 'SOL', 'addr' => ''],
  ],
  'items' => [
    'dmbot-premium' => ['cat' => 'DMBOT', 'icon' => '◈', 'color' => '#2ecc71', 'badge' => 'Популярное', 'price' => 299, 'period' => ['ru' => 'мес', 'ua' => 'міс', 'en' => 'mo'], 'name' => 'DMBOT Premium',
      'desc' => ['ru' => 'Расширенные функции модерации, авто-голос, FAQ-система и полный доступ к веб-дашборду.', 'ua' => 'Розширені функції модерації, авто-голос, FAQ-система та повний доступ до веб-дашборду.', 'en' => 'Advanced moderation, auto-voice, FAQ system and full web dashboard access.']],
    'dmbot-custom' => ['cat' => 'DMBOT', 'icon' => '❖', 'color' => '#a78bfa', 'badge' => 'VIP', 'price' => 1499, 'name' => ['ru' => 'Кастомная сборка DMBOT', 'ua' => 'Кастомна збірка DMBOT', 'en' => 'Custom DMBOT build'],
      'desc' => ['ru' => 'Индивидуальная настройка ботов, кастомные брендированные модули и персональный хостинг.', 'ua' => 'Індивідуальне налаштування ботів, кастомні брендовані модулі та персональний хостинг.', 'en' => 'Individual bot setup, custom branded modules and personal hosting.']],
    'sponsor' => ['cat' => 'nullrtp', 'icon' => '✦', 'color' => '#fbbf24', 'badge' => 'Поддержка', 'price' => 500, 'period' => ['ru' => 'мес', 'ua' => 'міс', 'en' => 'mo'], 'name' => ['ru' => 'Спонсорский статус nullrtp', 'ua' => 'Спонсорський статус nullrtp', 'en' => 'nullrtp sponsor status'],
      'desc' => ['ru' => 'Особая роль на Discord-сервере, выделенный статус на сайте и приоритетная поддержка 24/7.', 'ua' => 'Особлива роль на Discord-сервері, виділений статус на сайті та пріоритетна підтримка 24/7.', 'en' => 'Special Discord role, highlighted status on the site and priority 24/7 support.']],
  ],
];
