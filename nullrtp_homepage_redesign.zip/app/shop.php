<?php
function shop_items($S) { global $db; // товары живут в базе; products.php нужен только для первого заполнения
  $new = !$db->query("SELECT 1 FROM sqlite_master WHERE type='table' AND name='items'")->fetchColumn();
  $db->exec('CREATE TABLE IF NOT EXISTS items(id TEXT PRIMARY KEY,cat TEXT,icon TEXT,color TEXT,badge TEXT,price TEXT,period TEXT,stock INTEGER DEFAULT 1,name TEXT,descr TEXT,ts INTEGER)');
  if ($new) { $i = $db->prepare('INSERT INTO items(id,cat,icon,color,badge,price,period,stock,name,descr,ts) VALUES(?,?,?,?,?,?,?,?,?,?,?)');
    $j = fn($v) => json_encode(is_array($v) ? $v : ['ru' => (string)$v], JSON_UNESCAPED_UNICODE);
    foreach ($S['items'] ?? [] as $id => $p) $i->execute([$id, $p['cat'] ?? '', $p['icon'] ?? '◆', $p['color'] ?? '#2ecc71', $p['badge'] ?? '', (string)$p['price'], $j($p['period'] ?? ''), ($p['stock'] ?? true) === false ? 0 : 1, $j($p['name']), $j($p['desc'] ?? ''), time()]); }
  $d = fn($s) => array_filter((array)json_decode((string)$s, true), 'strlen'); $out = [];
  foreach ($db->query('SELECT * FROM items ORDER BY ts, rowid') as $r) $out[$r['id']] = ['cat' => $r['cat'], 'icon' => $r['icon'], 'color' => $r['color'], 'badge' => $r['badge'], 'price' => $r['price'], 'period' => $d($r['period']), 'stock' => (bool)$r['stock'], 'name' => $d($r['name']) ?: ['ru' => $r['id']], 'desc' => $d($r['descr'])];
  return $out; }
