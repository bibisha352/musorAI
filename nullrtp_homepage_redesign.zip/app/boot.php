<?php
$C = require __DIR__ . '/config.php';
$RL = require __DIR__ . '/roles.php';
$siteHost = (string)(parse_url($C['site'] ?? 'https://nullrtp.dev', PHP_URL_HOST) ?: 'nullrtp.dev');
$COOKIE_DOMAIN = '.' . preg_replace('/^www\\./i', '', $siteHost);
session_set_cookie_params(['path' => '/', 'domain' => $COOKIE_DOMAIN, 'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off', 'httponly' => true, 'samesite' => 'Lax']);
session_start();
$L = $_GET['lang'] ?? ($_COOKIE['l'] ?? 'ru');
if (!in_array($L, ['ru', 'ua', 'en'], true)) $L = 'ru';
if (isset($_GET['lang'])) setcookie('l', '', ['expires' => 1, 'path' => '/']);
if (isset($_GET['lang'])) setcookie('l', $L, ['expires' => time() + 31536000, 'path' => '/', 'domain' => '.' . parse_url($C['site'], PHP_URL_HOST), 'samesite' => 'Lax']);
$db = new PDO('sqlite:' . __DIR__ . '/app.sqlite');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); $db->exec('PRAGMA busy_timeout=5000');
$db->exec('CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,name TEXT,avatar TEXT,roles TEXT,joined INTEGER,synced INTEGER);
CREATE TABLE IF NOT EXISTS tickets(n INTEGER PRIMARY KEY AUTOINCREMENT,k1 TEXT,k2 TEXT,uid TEXT,topic TEXT,body TEXT,status TEXT DEFAULT \'open\',ts INTEGER);
CREATE TABLE IF NOT EXISTS msgs(id INTEGER PRIMARY KEY AUTOINCREMENT,tn INTEGER,uid TEXT,body TEXT,staff INTEGER,ts INTEGER);
CREATE TABLE IF NOT EXISTS files(id INTEGER PRIMARY KEY AUTOINCREMENT,tn INTEGER,name TEXT,path TEXT,mime TEXT,ts INTEGER);
CREATE TABLE IF NOT EXISTS votes(uid TEXT,target TEXT,v INTEGER,PRIMARY KEY(uid,target));
CREATE TABLE IF NOT EXISTS sess(sid TEXT PRIMARY KEY,uid TEXT,ua TEXT,ip TEXT,ts INTEGER,last INTEGER,ended INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS orders(n INTEGER PRIMARY KEY AUTOINCREMENT,k1 TEXT,k2 TEXT,uid TEXT,item TEXT,price TEXT,method TEXT,contact TEXT,status TEXT DEFAULT \'new\',ts INTEGER)');
foreach (['tickets ADD COLUMN subject TEXT', 'users ADD COLUMN banner TEXT', 'users ADD COLUMN bio TEXT', 'users ADD COLUMN color TEXT', 'users ADD COLUMN slug TEXT', 'users ADD COLUMN views INTEGER DEFAULT 0', 'users ADD COLUMN avu INTEGER DEFAULT 0', 'users ADD COLUMN bnu INTEGER DEFAULT 0', 'tickets ADD COLUMN closed_ts INTEGER', 'orders ADD COLUMN pid TEXT', 'orders ADD COLUMN purl TEXT', 'orders ADD COLUMN cx TEXT', 'users ADD COLUMN email TEXT', 'users ADD COLUMN pass TEXT', 'users ADD COLUMN verified INTEGER DEFAULT 0', 'users ADD COLUMN evt TEXT', 'users ADD COLUMN evts INTEGER', 'users ADD COLUMN rst TEXT', 'users ADD COLUMN rsts INTEGER', 'users ADD COLUMN did TEXT', 'users ADD COLUMN dname TEXT', 'users ADD COLUMN gid TEXT'] as $q) { try { $db->exec("ALTER TABLE $q"); } catch (Exception $e) {} }
$BN = ['linear-gradient(120deg,#052e16,#0a0c10 45%,#14532d)', 'linear-gradient(120deg,#0a0c10,#1e1b4b,#4c1d95)', 'linear-gradient(120deg,#1a0a0a,#450a0a,#7f1d1d)', 'linear-gradient(120deg,#0a1628,#0c4a6e,#0a0c10)', 'linear-gradient(120deg,#1c1917,#78350f,#0a0c10)', 'linear-gradient(120deg,#000,#1f2937,#000)'];
$TR = require __DIR__ . '/lang.php';
function t($k) { global $TR, $L; $p = explode('|', $TR[$k] ?? $k); return $p[['ru' => 0, 'ua' => 1, 'en' => 2][$L]] ?? $p[0]; }
function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function go($u) { header('Location: ' . $u); exit; }
function csrf() { return $_SESSION['t'] ?? ($_SESSION['t'] = bin2hex(random_bytes(16))); }
function chk() { if (!hash_equals(csrf(), (string)($_POST['t'] ?? $_GET['t'] ?? ''))) { http_response_code(403); exit('bad token'); } }
function col($c) { return preg_match('/^#[0-9a-f]{6}$/i', (string)$c) ? $c : ''; }
function me() { global $db; static $u = false;
  if ($u === false) { $u = null; if (!empty($_SESSION['uid'])) { $q = $db->prepare('SELECT * FROM users WHERE id=?'); $q->execute([$_SESSION['uid']]); $u = $q->fetch(PDO::FETCH_ASSOC) ?: null;
    if ($u && !empty($_SESSION['sid'])) { $s = $db->prepare('SELECT ended,last FROM sess WHERE sid=?'); $s->execute([$_SESSION['sid']]); $s = $s->fetch(PDO::FETCH_ASSOC);
      if ($s && $s['ended']) { $_SESSION = []; $u = null; } elseif ($s && time() - $s['last'] > 60) $db->prepare('UPDATE sess SET last=? WHERE sid=?')->execute([time(), $_SESSION['sid']]); } } }
  return $u; }
function admin() { global $C; $u = me(); if (!$u) return false; $ad = array_map('strtolower', array_map('strval', $C['admins'] ?? []));
  if (in_array(strtolower((string)$u['id']), $ad, true) || (!empty($u['verified']) && !empty($u['email']) && in_array(strtolower($u['email']), $ad, true))) return true;
  foreach (uroles($u) as $r) if (in_array(mb_strtolower($r[0]), ['admin', 'админ'], true)) return true; return false; }
function uroles($u) { $d = json_decode($u['roles'] ?: '[]', true); return is_array($d) ? array_values(array_filter($d, fn($x) => is_array($x) && count($x) >= 2)) : []; }
function avatar($u, $s = 128) {
  if (!empty($u['avu'])) return '/media.php?u=' . urlencode($u['id']) . '&k=av&v=' . (int)$u['avu'];
  if ($u['id'][0] === 'g') return $u['avatar'] ?: 'https://cdn.discordapp.com/embed/avatars/0.png';
  if ($u['avatar']) return "https://cdn.discordapp.com/avatars/{$u['id']}/{$u['avatar']}." . (str_starts_with($u['avatar'], 'a_') ? 'gif' : 'png') . "?size=$s";
  return 'https://cdn.discordapp.com/embed/avatars/' . (ctype_digit((string)$u['id']) ? ((int)$u['id'] >> 22) % 6 : crc32((string)$u['id']) % 6) . '.png'; }
function dc($m, $path, $tok = null, $body = null, $bot = false) { global $C;
  $o = [CURLOPT_CUSTOMREQUEST => $m, CURLOPT_RETURNTRANSFER => 1, CURLOPT_TIMEOUT => 10,
        CURLOPT_HTTPHEADER => ['Authorization: ' . ($bot ? 'Bot ' . $C['bot_token'] : 'Bearer ' . $tok), 'Content-Type: application/json']];
  if ($body) $o[CURLOPT_POSTFIELDS] = json_encode($body);
  $ch = curl_init('https://discord.com/api/v10' . $path); curl_setopt_array($ch, $o);
  $r = curl_exec($ch); return [curl_getinfo($ch, CURLINFO_HTTP_CODE), json_decode((string)$r, true)]; }
function post($u, $f) { $ch = curl_init($u); curl_setopt_array($ch, [CURLOPT_POST => 1, CURLOPT_RETURNTRANSFER => 1, CURLOPT_TIMEOUT => 10, CURLOPT_POSTFIELDS => http_build_query($f)]); return json_decode((string)curl_exec($ch), true) ?: []; }
function jget($u, $tok) { $ch = curl_init($u); curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => 1, CURLOPT_TIMEOUT => 10, CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $tok]]); return json_decode((string)curl_exec($ch), true) ?: []; }
function sync($id) { global $db, $C, $RL; $r = []; $c = 0;
  if ($id[0] !== 'g') { [$c, $m] = dc('GET', "/guilds/{$C['guild_id']}/members/$id", null, null, true);
    if ($c == 200) { $have = array_map('strval', $m['roles'] ?? []); foreach ($RL as $rid => $v) if (in_array((string)$rid, $have, true)) $r[] = $v; } }
  $db->prepare('UPDATE users SET roles=?,synced=? WHERE id=?')->execute([json_encode($r, JSON_UNESCAPED_UNICODE), time(), $id]); return $c; }
function asset($p) { return '/' . $p . '?v=' . (int)@filemtime(dirname(__DIR__) . '/' . $p); }
function langpath() { return e(strtok($_SERVER['REQUEST_URI'] ?? '/', '?')); }
function langmenu() { global $L; $o = '<details class="lg"><summary>' . strtoupper($L) . ' <i>⌃</i></summary><div class="menu">';
  foreach (['ru' => 'Русский', 'ua' => 'Українська', 'en' => 'English'] as $k => $v) $o .= '<a href="' . langpath() . '?lang=' . $k . '"' . ($k === $L ? ' class="cur"' : '') . '>' . $v . '</a>';
  return $o . '</div></details>'; }
function valid_next($n) { $n = (string)$n; return preg_match('#^/(?!/)[a-zA-Z0-9/_?=&.%-]*$#', $n) ? $n : '/profile/'; }
function ipk($p) { return $p . ':' . ($_SERVER['HTTP_CF_CONNECTING_IP'] ?? $_SERVER['REMOTE_ADDR'] ?? ''); }
function throttle($k, $max, $win) { global $db; $db->exec('CREATE TABLE IF NOT EXISTS fails(ip TEXT,ts INTEGER)');
  $q = $db->prepare('SELECT COUNT(*) FROM fails WHERE ip=? AND ts>?'); $q->execute([$k, time() - $win]); if ($q->fetchColumn() >= $max) return false;
  $db->prepare('INSERT INTO fails(ip,ts) VALUES(?,?)')->execute([$k, time()]); return true; }
function captcha_widget() { global $C; if (empty($C['rc_site'])) return ''; return '<div class="g-recaptcha" data-sitekey="' . e($C['rc_site']) . '" data-theme="dark"></div><script src="https://www.google.com/recaptcha/api.js" async defer></script>'; }
function captcha_ok() { global $C; if (empty($C['rc_site'])) return true; // reCAPTCHA выключена, пока в config.php нет ключей
  $r = post('https://www.google.com/recaptcha/api/siteverify', ['secret' => $C['rc_secret'] ?? '', 'response' => $_POST['g-recaptcha-response'] ?? '', 'remoteip' => $_SERVER['REMOTE_ADDR'] ?? '']); return !empty($r['success']); }
function login_session($u) { global $db; session_regenerate_id(true); $_SESSION['uid'] = $u['id']; $sid = bin2hex(random_bytes(16));
  $db->prepare('INSERT INTO sess(sid,uid,ua,ip,ts,last) VALUES(?,?,?,?,?,?)')->execute([$sid, $u['id'], mb_substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 200), $_SERVER['REMOTE_ADDR'] ?? '', time(), time()]); $_SESSION['sid'] = $sid; }
function plogo() { echo '<div class="plogo"><img src="/assets/img/favicon.svg" alt=""><b>nullrtp.dev</b></div>'; }
function oauthbuttons() {
  echo '<div class="oauth-buttons"><a class="oauth-btn oauth-discord" href="/auth.php?a=discord"><span class="oauth-mark">◉</span><span>Продолжить через Discord</span></a><a class="oauth-btn oauth-google" href="/auth.php?a=google"><span class="oauth-google-mark">G</span><span>Продолжить через Google</span></a></div><div class="oauth-divider"><span>или войти по логину</span></div>';
}
function logincard($next = '/profile/') {
  $er = $GLOBALS['lerr'] ?? '';
  if (!$er && isset($_GET['oauth'])) $er = ['setup' => 'Вход через этот сервис пока не настроен администратором.', 'email' => 'Сервис не подтвердил адрес электронной почты.', 'conflict' => 'Этот способ входа уже связан с другим аккаунтом.', 'failed' => 'Не удалось выполнить вход. Попробуй ещё раз.'][$_GET['oauth']] ?? '';
  plogo(); echo '<section class="lcard modal"><a class="mx" href="/" aria-label="close">×</a>'; oauthbuttons();
  echo '<form method="post" action="/login/" class="tform mf"><input type="hidden" name="next" value="' . e(valid_next($next)) . '"><input name="login" placeholder="' . e(t('f_login') . ' / ' . t('f_email')) . '" required autocomplete="username"><input type="password" name="pass" placeholder="' . e(t('f_pass')) . '" required autocomplete="current-password">' . captcha_widget() . ($er ? '<p class="err">' . e($er) . '</p>' : '') . '<button class="btn-green wide" type="submit">' . e(t('login')) . '</button></form><p class="mlinks"><a href="/forgot/">' . e(t('forgot')) . '</a><a href="/resend/">' . e(t('resend_q')) . '</a><span>' . e(t('no_acc')) . ' <a href="/register/">' . e(t('register')) . '</a></span></p></section>';
}
function top($title, $act = '', $home = false) {
  global $L, $C; $u = me(); $host = strtolower(preg_replace('/:\\d+$/', '', (string)($_SERVER['HTTP_HOST'] ?? ''))); $adminHost = $host === 'admin.nullrtp.dev'; $base = rtrim((string)($C['site'] ?? 'https://nullrtp.dev'), '/');
  $nav = $adminHost ? ['dashboard'=>['/','ПАНЕЛЬ'],'users'=>['/users/','ПОЛЬЗОВАТЕЛИ'],'roles'=>['/roles/','РОЛИ'],'mail'=>['/mail/','ПОЧТА'],'shop'=>['/shop/','МАГАЗИН'],'support'=>['/support/','ТИКЕТЫ']] : ['home'=>['/',t('home')],'forum'=>['/forum/',t('forum')],'support'=>['/support/',t('support')]];
  echo '<!DOCTYPE html><html lang="' . ($L === 'ua' ? 'uk' : $L) . '"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#050907"><title>' . e($title) . ' · nullrtp.dev</title><link rel="icon" href="/assets/img/favicon.svg" type="image/svg+xml"><link rel="stylesheet" href="' . asset('assets/css/style.css') . '"><link rel="stylesheet" href="' . asset('assets/css/app.css') . '"><link rel="stylesheet" href="' . asset('assets/css/v02.css') . '"></head><body' . ($home ? ' class="home-page"' : '') . '>';
  if ($home) echo '<div id="preloader" class="preloader"><span id="pre-text" class="pre-text">nullrtp</span></div>';
  echo '<div class="bg-slot" aria-hidden="true"><video class="matrix-video" autoplay muted loop playsinline preload="none" data-src="/assets/video/matrix.mp4"></video><div class="video-mask"></div></div><div class="site shell"><div class="bar"><a href="/" class="logo">nullrtp.dev<span class="logo-caret">_</span></a><nav aria-label="Основная навигация">';
  foreach ($nav as $key => [$href,$label]) echo '<a href="' . e($href) . '"' . ($key === $act ? ' class="active"' : '') . '><span>' . e($label) . '</span></a>';
  echo '</nav><div class="top">' . langmenu();
  if ($u) { $color = col($u['color']); echo '<details class="dd"><summary><img src="' . e(avatar($u,64)) . '" alt=""><span class="nm"><b' . ($color ? ' style="color:' . e($color) . '"' : '') . '>' . e($u['name']) . '</b></span></summary><div class="menu"><a href="' . e($base) . '/profile/">Мой профиль</a>';
    if (!$adminHost && admin()) echo '<a class="admin-entry" href="https://admin.nullrtp.dev/">Админ-панель ↗</a>';
    echo '<a href="' . e($base) . '/auth.php?a=logout&amp;t=' . csrf() . '">Выйти</a></div></details>';
  } else echo '<a class="auth" href="' . e($base) . '/register/"><i>✚</i>' . e(t('register')) . '</a><a class="auth" href="' . e($base) . '/login/"><i>➜</i>' . e(t('login')) . '</a>';
  echo '</div></div><div class="content"><main>';
}
function bottom() {
  global $L,$C; $host = strtolower(preg_replace('/:\\d+$/', '', (string)($_SERVER['HTTP_HOST'] ?? ''))); $adminHost = $host === 'admin.nullrtp.dev'; $langs='';
  foreach (['ru'=>'RU','ua'=>'UA','en'=>'EN'] as $k=>$v) $langs .= '<a href="' . langpath() . '?lang=' . $k . '"' . ($k===$L?' class="cur"':'') . '>' . $v . '</a>';
  echo '</main>';
  if ($adminHost) echo '<footer class="foot foot-admin"><a href="' . e(rtrim((string)($C['site'] ?? 'https://nullrtp.dev'), '/')) . '/">← nullrtp.dev</a><span>ADMIN / NULLRTP</span></footer>';
  else echo '<footer class="foot foot-minimal"><a class="logo" href="/">nullrtp.dev<span class="logo-caret">_</span></a><div class="ln">' . $langs . '</div></footer>';
  echo '</div></div><div id="ck" class="ck" hidden><span>' . t('ck_text') . '</span><button id="ckb" class="btn-green" type="button">' . t('ck_ok') . '</button></div><script src="' . asset('assets/js/main.js') . '" defer></script><script src="' . asset('assets/js/fx.js') . '" defer></script><script src="' . asset('assets/js/app.js') . '" defer></script></body></html>';
}
function icon($n) { return $n === 'dc' ? '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M5 6c2-1.5 4-2 7-2s5 .5 7 2c1.5 3 2.5 6.5 2.5 10.5-2 1.5-3.5 2-5 2.5l-1-2c-2 .5-5 .5-7 0l-1 2c-1.5-.5-3-1-5-2.5C3 12.5 3.5 9 5 6z"/><circle cx="9" cy="12" r="1.6" fill="#0a0c10"/><circle cx="15" cy="12" r="1.6" fill="#0a0c10"/></svg>' : '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M21.6 7.2c-.2-.9-.9-1.5-1.8-1.7C18.3 5 12 5 12 5s-6.3 0-7.8.5c-.9.2-1.6.8-1.8 1.7C2 8.7 2 12 2 12s0 3.3.4 4.8c.2.9.9 1.5 1.8 1.7C5.7 19 12 19 12 19s6.3 0 7.8-.5c.9-.2 1.6-.8 1.8-1.7.4-1.5.4-4.8.4-4.8s0-3.3-.4-4.8zM10 15V9l5.2 3L10 15z"/></svg>'; }
if (is_file(__DIR__ . '/invite.php')) { require_once __DIR__ . '/invite.php'; invite_sweep(); } // чистим просроченные папки приглашений
