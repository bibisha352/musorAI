<?php
function jpg($tmp, $out, $w, $h) { // перекодирование через GD с обрезкой: убирает скрытые данные
  if (!function_exists('imagecreatefromstring')) return false;
  $i = @getimagesize($tmp); if (!$i || !in_array($i[2], [IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_WEBP, IMAGETYPE_GIF], true) || $i[0] * $i[1] > 25000000) return false;
  $s = @imagecreatefromstring((string)file_get_contents($tmp)); if (!$s) return false;
  if ($i[2] === IMAGETYPE_JPEG && function_exists('exif_read_data')) { $ex = @exif_read_data($tmp); $deg = [3 => 180, 6 => -90, 8 => 90][$ex['Orientation'] ?? 1] ?? 0; if ($deg) { $rot = imagerotate($s, $deg, 0); if ($rot) $s = $rot; } }
  $sw = imagesx($s); $sh = imagesy($s); $dr = $w / $h;
  if ($sw / $sh > $dr) { $ch = $sh; $cw = (int)round($sh * $dr); } else { $cw = $sw; $ch = (int)round($sw / $dr); }
  $d = imagecreatetruecolor($w, $h); imagefill($d, 0, 0, imagecolorallocate($d, 10, 12, 16));
  imagecopyresampled($d, $s, 0, 0, (int)(($sw - $cw) / 2), (int)(($sh - $ch) / 2), $w, $h, $cw, $ch);
  @mkdir(dirname($out), 0755, true); return imagejpeg($d, $out, 85); }
function files($tn = null) { global $db; // без $tn только проверяет, с $tn сохраняет
  if (empty($_FILES['f']['name'][0] ?? '')) return true;
  $n = 0; $ok = ['image/png', 'image/jpeg', 'image/webp', 'image/gif'];
  foreach ($_FILES['f']['tmp_name'] as $i => $tmp) { $er = $_FILES['f']['error'][$i];
    if ($er === UPLOAD_ERR_NO_FILE) continue; if (++$n > 3) return false;
    $inf = ($er === UPLOAD_ERR_OK && $_FILES['f']['size'][$i] <= 3145728 && is_uploaded_file($tmp)) ? @getimagesize($tmp) : false;
    if (!$inf || !in_array($inf['mime'], $ok, true)) return false;
    if ($tn !== null) { $nm = bin2hex(random_bytes(12)); @mkdir(__DIR__ . '/uploads/t', 0755, true); move_uploaded_file($tmp, __DIR__ . "/uploads/t/$nm");
      $db->prepare('INSERT INTO files(tn,name,path,mime,ts) VALUES(?,?,?,?,?)')->execute([$tn, mb_substr(preg_replace('/[^\w. -]/u', '_', basename($_FILES['f']['name'][$i])), 0, 80), $nm, $inf['mime'], time()]); } }
  return true; }
