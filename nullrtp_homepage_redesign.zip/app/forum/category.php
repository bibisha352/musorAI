<?php $all = isset($_GET['l']) && !$cid; $c = $all ? ['name' => t('topics_all'), 'desc' => ''] : ($CATS[$cid] ?? null); if (!$c) fnf(); $can = !$all && $u && (empty($c['staff']) || $adm);
$q = $db->prepare('SELECT t.*, u.name, u.avatar, u.avu, (SELECT COUNT(*) - 1 FROM f_posts WHERE tid=t.id) AS r FROM f_topics t JOIN users u ON u.id=t.uid WHERE (?=0 OR t.cat=?) ORDER BY t.pinned DESC, t.last DESC LIMIT 100'); $q->execute([$cid, $cid]);
$rows = $q->fetchAll(PDO::FETCH_ASSOC);
top(ftx($c['name']), 'forum'); echo '<div class="fwrap">'; fside($all ? -1 : $cid); echo '<div class="fmain">'; ?>
<section class="hero c fhead">
  <p class="kicker"><a href="/forum/">← <?= e(t('forum')) ?></a></p>
  <h1><?= e(ftx($c['name'])) ?></h1>
  <p class="lead"><?= e(ftx($c['desc'] ?? '')) ?></p>
  <input id="q" class="search" type="search" placeholder="<?= e(t('fsearch')) ?>" autocomplete="off">
  <?php if ($can) echo '<a class="btn-green big" href="/forum/?new=' . $cid . '">' . e(t('new_topic')) . '</a>'; elseif (!$u) echo '<a class="ghost" href="/login/">' . e(t('login_to_post')) . '</a>'; ?>
</section>
<div class="tlist ftl"><?php foreach ($rows as $r) echo '<a class="trow" data-s="' . e($r['title']) . '" href="/forum/?t=' . (int)$r['id'] . '"><img class="av" src="' . fav($r) . '" alt=""><span><b>' . ($r['pinned'] ? '▲ ' : '') . ($r['locked'] ? '✕ ' : '') . e($r['title']) . '</b><br><small>' . e($r['name']) . '</small></span><em class="st">' . (int)$r['r'] . ' ' . e(t('replies')) . '</em><small>' . e(date('d M H:i', (int)$r['last'])) . '</small></a>'; if (!$rows) echo '<p>' . e(t('no_topics')) . '</p>'; ?></div>
</div></div>
<?php bottom();
