<?php $q = $db->prepare('SELECT * FROM f_topics WHERE id=?'); $q->execute([$tid]); $tp = $q->fetch(PDO::FETCH_ASSOC); if (!$tp) fnf();
$c = $CATS[$tp['cat']] ?? ['name' => '?'];
$fp = $db->prepare('SELECT MIN(id) FROM f_posts WHERE tid=?'); $fp->execute([$tid]); $first = (int)$fp->fetchColumn();
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $u) { chk(); $a = $_POST['act'] ?? '';
  if ($a === 'reply' && (!$tp['locked'] || $adm)) { $b = trim((string)($_POST['body'] ?? ''));
    $r = $db->prepare('SELECT COUNT(*) FROM f_posts WHERE uid=? AND ts>?'); $r->execute([$u['id'], time() - 60]);
    if (mb_strlen($b) >= 2 && mb_strlen($b) <= 5000 && $r->fetchColumn() < 5) { $n = time(); $db->prepare('INSERT INTO f_posts(tid,uid,body,ts) VALUES(?,?,?,?)')->execute([$tid, $u['id'], $b, $n]); $db->prepare('UPDATE f_topics SET last=? WHERE id=?')->execute([$n, $tid]); } }
  elseif ($a === 'delpost') { $d = $db->prepare('SELECT * FROM f_posts WHERE id=? AND tid=?'); $d->execute([(int)($_POST['pid'] ?? 0), $tid]); $p = $d->fetch(PDO::FETCH_ASSOC);
    if ($p && (int)$p['id'] !== $first && ($adm || $p['uid'] === $u['id'])) $db->prepare('DELETE FROM f_posts WHERE id=?')->execute([$p['id']]); }
  elseif ($adm && $a === 'pin') $db->prepare('UPDATE f_topics SET pinned=1-pinned WHERE id=?')->execute([$tid]);
  elseif ($adm && $a === 'lock') $db->prepare('UPDATE f_topics SET locked=1-locked WHERE id=?')->execute([$tid]);
  elseif ($adm && $a === 'deltopic') { $db->prepare('DELETE FROM f_posts WHERE tid=?')->execute([$tid]); $db->prepare('DELETE FROM f_topics WHERE id=?')->execute([$tid]); go('/forum/?c=' . (int)$tp['cat']); }
  go("/forum/?t=$tid"); }
$q = $db->prepare('SELECT p.*, u.name, u.avatar, u.avu, u.roles, u.color FROM f_posts p JOIN users u ON u.id=p.uid WHERE p.tid=? ORDER BY p.id LIMIT 300'); $q->execute([$tid]); $ps = $q->fetchAll(PDO::FETCH_ASSOC);
top($tp['title'], 'forum'); echo '<div class="fwrap">'; fside((int)$tp['cat']); echo '<div class="fmain">'; ?>
<div class="ftitle"><p class="kicker"><a href="/forum/?c=<?= (int)$tp['cat'] ?>">← <?= e(ftx($c['name'])) ?></a></p><h1><?= $tp['pinned'] ? '▲ ' : '' ?><?= $tp['locked'] ? '✕ ' : '' ?><?= e($tp['title']) ?></h1></div>
<?php if ($adm) echo '<div class="fmod">' . forum_action_form('pin', t($tp['pinned'] ? 'unpin' : 'pin')) . forum_action_form('lock', t($tp['locked'] ? 'unlock' : 'lock')) . forum_action_form('deltopic', t('del')) . '</div>'; ?>
<?php foreach ($ps as $i => $p) { $co = col($p['color']); $m = uroles($p)[0] ?? null; $mc = $m ? (col($m[1]) ?: '#2ecc71') : '';
  echo '<article class="fpost' . ($i ? '' : ' first') . '"><aside><img class="av big" src="' . fav($p) . '" alt=""><b' . ($co ? ' style="color:' . $co . '"' : '') . '>' . e($p['name']) . '</b>' . ($m ? '<span class="role" style="color:' . $mc . ';box-shadow:inset 0 0 0 1px ' . $mc . '">' . e($m[0]) . '</span>' : '') . '</aside><div><small>' . e(date('d M Y, H:i', (int)$p['ts'])) . '</small><p>' . nl2br(e($p['body'])) . '</p>';
  if ($u && (int)$p['id'] !== $first && ($adm || $p['uid'] === $u['id'])) echo forum_action_form('delpost', t('del'), '<input type="hidden" name="pid" value="' . (int)$p['id'] . '">');
  echo '</div></article>'; } ?>
<?php if (!$u) echo '<div class="fmod"><a class="btn-green" href="/login/">' . e(t('login_to_post')) . '</a></div>';
elseif ($tp['locked'] && !$adm) echo '<div class="fmod"><p>' . e(t('locked_note')) . '</p></div>';
else { ?>
<section class="lcard wide fform"><form method="post" class="tform"><input type="hidden" name="t" value="<?= csrf() ?>"><input type="hidden" name="act" value="reply">
  <textarea name="body" rows="5" maxlength="5000" required></textarea><button class="btn-green" type="submit"><?= e(t('reply')) ?></button></form></section>
<?php } echo '</div></div>'; bottom();
