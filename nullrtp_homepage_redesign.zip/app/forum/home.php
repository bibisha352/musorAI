<?php $st = []; foreach ($db->query('SELECT cat, SUM(ts > ' . (time() - 2592000) . ') n FROM f_topics GROUP BY cat') as $r) $st[$r['cat']] = (int)$r['n'];
$lat = $db->query('SELECT t.*, u.name, u.avatar, u.avu, (SELECT COUNT(*) - 1 FROM f_posts WHERE tid=t.id) AS r FROM f_topics t JOIN users u ON u.id=t.uid ORDER BY t.last DESC LIMIT 10')->fetchAll(PDO::FETCH_ASSOC);
top(t('forum'), 'forum'); echo '<div class="fwrap">'; fside(0); ?>
<div class="fmain">
  <div class="ftool"><input id="q" class="search" type="search" placeholder="<?= e(t('fsearch')) ?>" autocomplete="off"></div>
  <div class="fcols">
    <section><div class="fh"><span><?= e(t('forum')) ?></span><span><?= e(t('topics')) ?></span></div>
      <?php foreach ($CATS as $id => $c) { $pc = col($c['color'] ?? '') ?: '#2ecc71';
        echo '<a class="fcr" href="/forum/?c=' . (int)$id . '" data-s="' . e(ftx($c['name']) . ' ' . ftx($c['desc'] ?? '')) . '" style="--pc:' . $pc . '"><div><b><i></i>' . e(ftx($c['name'])) . '</b><small>' . e(ftx($c['desc'] ?? '')) . '</small></div><em>' . ($st[$id] ?? 0) . ' ' . e(t('per_month')) . '</em></a>'; } ?></section>
    <aside><div class="fh"><span><?= e(t('latest')) ?></span></div>
      <?php foreach ($lat as $r) { $c = $CATS[$r['cat']] ?? null; $pc = $c ? (col($c['color'] ?? '') ?: '#2ecc71') : '#2ecc71';
        echo '<a class="flr" data-s="' . e($r['title']) . '" href="/forum/?t=' . (int)$r['id'] . '" style="--pc:' . $pc . '"><img class="av" src="' . fav($r) . '" alt=""><span>' . ($r['pinned'] ? '▲ ' : '') . e($r['title']) . '<small><i></i>' . e($c ? ftx($c['name']) : '?') . '</small></span><div>' . (int)$r['r'] . '<small>' . e(ago($r['last'])) . '</small></div></a>'; }
        if (!$lat) echo '<p style="padding:14px">' . e(t('no_topics')) . '</p>'; ?></aside>
  </div></div></div>
<?php bottom();
