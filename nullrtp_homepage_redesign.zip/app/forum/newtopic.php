<?php $c = $CATS[$nid] ?? null; if (!$c) fnf();
if (!$u) { top(t('new_topic'), 'forum'); logincard('/forum/'); bottom(); exit; }
if (!empty($c['staff']) && !$adm) go('/forum/?c=' . $nid);
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') { chk(); $ti = trim((string)($_POST['title'] ?? '')); $b = trim((string)($_POST['body'] ?? ''));
  $q = $db->prepare('SELECT COUNT(*) FROM f_posts WHERE uid=? AND ts>?'); $q->execute([$u['id'], time() - 60]);
  if (mb_strlen($ti) < 3 || mb_strlen($ti) > 120 || mb_strlen($b) < 10 || mb_strlen($b) > 5000) $err = t('e_len');
  elseif ($q->fetchColumn() >= 5) $err = t('e_rate');
  else { $n = time(); $db->prepare('INSERT INTO f_topics(cat,uid,title,ts,last) VALUES(?,?,?,?,?)')->execute([$nid, $u['id'], $ti, $n, $n]); $tid = $db->lastInsertId();
    $db->prepare('INSERT INTO f_posts(tid,uid,body,ts) VALUES(?,?,?,?)')->execute([$tid, $u['id'], $b, $n]); go("/forum/?t=$tid"); } }
top(t('new_topic'), 'forum'); echo '<div class="fwrap">'; fside($nid); echo '<div class="fmain">'; ?>
<section class="lcard wide"><h1><?= e(t('new_topic')) ?> · <?= e(ftx($c['name'])) ?></h1>
  <form method="post" class="tform"><input type="hidden" name="t" value="<?= csrf() ?>">
    <label><?= e(t('title')) ?></label><input name="title" maxlength="120" required>
    <label><?= e(t('text')) ?></label><textarea name="body" rows="10" maxlength="5000" required></textarea>
    <?php if ($err) echo '<p class="err">' . e($err) . '</p>'; ?>
    <button class="btn-green" type="submit"><?= e(t('publish')) ?></button>
  </form></section>
</div></div>
<?php bottom();
