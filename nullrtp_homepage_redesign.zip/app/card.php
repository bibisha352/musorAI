<?php
function pcard($u, $own) { global $BN, $db; $me = me(); $id = $u['id']; $rl = uroles($u); $co = col($u['color']);
  $st = 'background-image:' . (!empty($u['bnu']) ? 'url(/media.php?u=' . urlencode($id) . '&k=bn&v=' . (int)$u['bnu'] . ');background-size:cover;background-position:center;animation:none' : ($BN[(int)$u['banner']] ?? $BN[0]));
  $v = $db->prepare('SELECT SUM(v=1),SUM(v=-1) FROM votes WHERE target=?'); $v->execute([$id]); [$lk, $dl] = array_map('intval', $v->fetch(PDO::FETCH_NUM));
  echo '<section class="pcard"><div class="pban" style="' . e($st) . '"></div><div class="pstat">';
  if (!$own && $me) echo '<form method="post"><input type="hidden" name="t" value="' . csrf() . '"><button name="v" value="up">▲ ' . $lk . '</button><button name="v" value="down">▼ ' . $dl . '</button></form>';
  else echo '<span>▲ ' . $lk . '</span><span>▼ ' . $dl . '</span>';
  echo '<span>◉ ' . (int)$u['views'] . '</span></div><div class="avatar big"><img src="' . e(avatar($u, 256)) . '" alt=""></div><h1' . ($co ? ' style="color:' . $co . '"' : '') . '>' . e($u['name']) . '</h1><div class="roles">';
  foreach ($rl as $x) { $c = col($x[1]) ?: '#2ecc71'; echo '<span class="role" style="color:' . $c . ';box-shadow:inset 0 0 0 1px ' . $c . '">' . e($x[0]) . '</span>'; }
  echo '</div>';
  if ($u['bio']) echo '<p class="bio">' . e($u['bio']) . '</p>';
  if (!empty($u['dname'])) echo '<p class="sub">Discord: ' . e($u['dname']) . '</p>';
  echo '<p class="sub">' . e(t('member_since')) . ' ' . e(date('M Y', (int)$u['joined'])) . ($u['slug'] ? ' · nullrtp.dev/u/' . e($u['slug']) : '') . '</p>';
  if ($own) echo '<div class="pact"><a class="btn-green" href="/profile/?tab=settings">' . e(t('settings')) . '</a><a class="ghost" href="/profile/?tab=discord">' . e(t('discord')) . '</a><a class="ghost" href="/auth.php?a=logout&amp;t=' . csrf() . '">' . e(t('logout')) . '</a></div>';
  echo '</section>'; }

function devcard($u) { global $db;
  $q = $db->prepare('SELECT * FROM sess WHERE uid=? ORDER BY last DESC LIMIT 30'); $q->execute([$u['id']]);
  echo '<section class="lcard wide" id="devices"><h1>' . e(t('devices')) . '</h1><p>' . e(t('dev_hint')) . '</p><div class="tlist">';
  foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $s) { $cur = $s['sid'] === ($_SESSION['sid'] ?? '');
    echo '<div class="trow dev"><span><b>' . e($s['ua'] ?: '?') . '</b><br><small>IP ' . e($s['ip']) . ' · ' . e(date('d M Y H:i', (int)$s['ts'])) . ' · ' . e(t('last_seen')) . ' ' . e(date('d M H:i', (int)$s['last'])) . '</small></span><em class="st">' . e($cur ? t('current') : ($s['ended'] ? t('ended') : t('active'))) . '</em>';
    if (!$cur && !$s['ended']) echo '<form method="post" action="/profile/devices/"><input type="hidden" name="t" value="' . csrf() . '"><input type="hidden" name="sid" value="' . e($s['sid']) . '"><button class="ghost" type="submit">' . e(t('end_s')) . '</button></form>';
    echo '</div>'; }
  echo '</div></section>'; }

function dcard($u) { global $C; $M = ['ok' => t('dc_linked'), 'bad' => t('dc_bad'), 'fail' => t('dc_bad'), 'taken' => t('dc_taken')]; $dl = (string)($_GET['dl'] ?? '');
  echo '<section class="lcard wide"><h1>Discord</h1>';
  if (isset($M[$dl])) echo '<p class="' . ($dl === 'ok' ? '' : 'err') . '">' . e($M[$dl]) . '</p>';
  if (!empty($u['did'])) echo '<p style="color:#e8eaee">' . e(t('dc_linked')) . ': <b>' . e($u['dname']) . '</b> <small>(' . e($u['did']) . ')</small></p><form method="post"><input type="hidden" name="t" value="' . csrf() . '"><input type="hidden" name="act" value="dunlink"><button class="ghost" type="submit">' . e(t('dc_unlink')) . '</button></form>';
  elseif (empty($C['client_id']) || empty($C['client_secret'])) echo '<p>' . e(t('dc_none')) . '</p>';
  else echo '<a class="btn-green" href="/auth.php?a=dlink">' . e(t('dc_link')) . '</a>';
  echo '</section>'; }
