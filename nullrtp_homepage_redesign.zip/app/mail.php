<?php // письма от no-reply@nullrtp.dev (через mail() хостинга)
function mail_log($m) { @file_put_contents(__DIR__ . '/mail.log', date('c') . ' ' . $m . "\n", FILE_APPEND); $GLOBALS['mail_err'] = $m; }
function smtp_send($to, $subject, $html) { global $C; $S = $C['smtp']; $from = $C['mail_from'] ?? $S['user']; $sec = $S['secure'] ?? 'ssl'; $port = (int)($S['port'] ?? ($sec === 'ssl' ? 465 : 587));
  $fp = @stream_socket_client(($sec === 'ssl' ? 'ssl://' : 'tcp://') . $S['host'] . ':' . $port, $en, $es, 15);
  if (!$fp) { mail_log("SMTP: не удалось подключиться к {$S['host']}:$port ($es)"); return false; }
  stream_set_timeout($fp, 15);
  $rd = function () use ($fp) { $o = ''; while (($l = fgets($fp, 515)) !== false) { $o .= $l; if (strlen($l) < 4 || $l[3] === ' ') break; } return $o; };
  $ex = function ($cmd, $ok) use ($fp, $rd) { if ($cmd !== null) fwrite($fp, $cmd . "\r\n"); $r = $rd(); return in_array(substr($r, 0, 3), (array)$ok, true) ? true : trim($r); };
  $seq = [[null, '220'], ['EHLO nullrtp.dev', '250']];
  foreach ($seq as [$c, $ok]) if (($r = $ex($c, $ok)) !== true) { mail_log("SMTP: $r"); return false; }
  if ($sec === 'tls') { $r = $ex('STARTTLS', '220'); if ($r !== true || !@stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) { mail_log('SMTP: STARTTLS не удался ' . (is_string($r) ? $r : '')); return false; }
    if (($r = $ex('EHLO nullrtp.dev', '250')) !== true) { mail_log("SMTP: $r"); return false; } }
  foreach ([['AUTH LOGIN', '334'], [base64_encode($S['user']), '334'], [base64_encode($S['pass']), '235'], ["MAIL FROM:<$from>", '250'], ["RCPT TO:<$to>", ['250', '251']], ['DATA', '354']] as [$c, $ok]) if (($r = $ex($c, $ok)) !== true) { mail_log('SMTP: ' . $r); return false; }
  $h = 'Date: ' . date('r') . "\r\nFrom: nullrtp.dev <$from>\r\nTo: <$to>\r\nSubject: =?UTF-8?B?" . base64_encode($subject) . "?=\r\nMessage-ID: <" . bin2hex(random_bytes(8)) . "@nullrtp.dev>\r\nMIME-Version: 1.0\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" . chunk_split(base64_encode($html));
  fwrite($fp, $h . "\r\n.\r\n"); $r = $rd(); fwrite($fp, "QUIT\r\n"); fclose($fp);
  if (substr($r, 0, 3) !== '250') { mail_log('SMTP: письмо отклонено: ' . trim($r)); return false; }
  return true; }
function send_mail($to, $subject, $html) { global $C; $GLOBALS['mail_err'] = '';
  if (!empty($C['smtp']['host'])) return smtp_send($to, $subject, $html); // надёжнее: отправка через почтовый ящик по SMTP
  $from = $C['mail_from'] ?? 'no-reply@nullrtp.dev';
  $h = "MIME-Version: 1.0\r\nContent-Type: text/html; charset=UTF-8\r\nFrom: nullrtp.dev <$from>\r\nReply-To: $from\r\n"; $s = '=?UTF-8?B?' . base64_encode($subject) . '?=';
  $ok = @mail($to, $s, $html, $h, '-f' . $from) ?: @mail($to, $s, $html, $h);
  if (!$ok) mail_log('mail(): хостинг отклонил отправку (функция отключена или нет прав). Настрой SMTP в config.php');
  return $ok; }
function mail_html($greet, $title, $text, $btn, $url) { $u = e($url);
  return '<!DOCTYPE html><html><body style="margin:0;background:#05070a;font-family:Arial,sans-serif"><table width="100%" cellpadding="0" cellspacing="0" style="background:#05070a"><tr><td align="center" style="padding:30px 10px"><table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;background:#0a0c10;border:1px solid #14301f;border-radius:10px">'
   . '<tr><td align="center" style="padding:34px 20px 20px"><img src="https://nullrtp.dev/assets/img/favicon.png" width="36" height="36" alt="" style="vertical-align:middle"> <span style="font-size:26px;font-weight:700;color:#fff;vertical-align:middle;letter-spacing:1px">nullrtp.dev</span></td></tr>'
   . '<tr><td style="height:90px;background:#0b2a17;background-image:linear-gradient(120deg,#052e16,#0a0c10 55%,#14532d)">&nbsp;</td></tr>'
   . '<tr><td style="padding:34px 40px 10px;color:#9aa3ad;font-size:14px">' . $greet . '</td></tr><tr><td style="padding:0 40px 8px;color:#fff;font-size:30px;font-weight:700">' . $title . '</td></tr>'
   . '<tr><td style="padding:14px 40px 24px;color:#c8ccd4;font-size:15px;line-height:1.7">' . $text . '</td></tr>'
   . '<tr><td align="center" style="padding:0 40px 14px"><a href="' . $u . '" style="display:inline-block;padding:14px 34px;background:#2ecc71;color:#0a0c10;font-weight:700;text-decoration:none;border-radius:6px">' . $btn . '</a></td></tr>'
   . '<tr><td align="center" style="padding:0 40px 30px;font-size:12px"><a href="' . $u . '" style="color:#2ecc71;word-break:break-all">' . $u . '</a></td></tr>'
   . '<tr><td align="center" style="padding:18px 20px 26px;border-top:1px solid #14301f;color:#4f535c;font-size:12px">nullrtp.dev © ' . date('Y') . '</td></tr></table></td></tr></table></body></html>'; }
function send_conf($to, $login, $tk) { global $C; $url = $C['site'] . '/confirm/?emtoken=' . $tk;
  return send_mail($to, t('m_conf_s'), mail_html(sprintf(t('m_hello'), '<span style="color:#2ecc71">' . e($login) . '</span>'), e(t('m_conf_s')), e(t('m_conf_b')), e(t('m_btn_conf')), $url)); }
function send_reset($to, $login, $tk) { global $C; $url = $C['site'] . '/reset/?token=' . $tk;
  return send_mail($to, t('m_reset_s'), mail_html(sprintf(t('m_hello'), '<span style="color:#2ecc71">' . e($login) . '</span>'), e(t('m_reset_s')), e(t('m_reset_b')), e(t('m_btn_reset')), $url)); }
