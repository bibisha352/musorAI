<?php // РАЗДЕЛЫ ФОРУМА — редактируй. staff => true: создавать темы может только админ. Номера используются в ссылках, не меняй их у существующих разделов.
return [
  1 => ['icon' => '◈', 'color' => '#ef4444', 'staff' => true, 'name' => ['ru' => 'Новости', 'ua' => 'Новини', 'en' => 'News'], 'desc' => ['ru' => 'Свежие новости проектов', 'ua' => 'Свіжі новини проєктів', 'en' => 'Keep up with the latest project news']],
  2 => ['icon' => '●', 'color' => '#2ecc71', 'name' => 'NullCore', 'desc' => ['ru' => 'Обсуждение NullCore: идеи, баги, вопросы', 'ua' => 'Обговорення NullCore: ідеї, баги, питання', 'en' => 'NullCore discussions: ideas, bugs, questions']],
  3 => ['icon' => '✦', 'color' => '#38bdf8', 'name' => ['ru' => 'Помощь', 'ua' => 'Допомога', 'en' => 'Help'], 'desc' => ['ru' => 'Вопросы и ответы', 'ua' => 'Питання та відповіді', 'en' => 'Questions and answers']],
  5 => ['icon' => '☾', 'color' => '#84cc16', 'name' => 'nullrtp Lua', 'desc' => ['ru' => 'Обсуждение nullrtp Lua: идеи, баги, конфиги', 'ua' => 'Обговорення nullrtp Lua: ідеї, баги, конфіги', 'en' => 'nullrtp Lua discussions: ideas, bugs, configs']],
  4 => ['icon' => '✕', 'color' => '#a855f7', 'name' => ['ru' => 'Оффтоп', 'ua' => 'Офтоп', 'en' => 'Offtop'], 'desc' => ['ru' => 'Всё остальное', 'ua' => 'Все інше', 'en' => 'Everything else']],
];
