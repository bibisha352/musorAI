<?php // общие функции форума (форум живёт на nullrtp.dev/forum и использует вход, базу и шапку основного сайта)
$db->exec('CREATE TABLE IF NOT EXISTS f_topics(id INTEGER PRIMARY KEY AUTOINCREMENT,cat INTEGER,uid TEXT,title TEXT,pinned INTEGER DEFAULT 0,locked INTEGER DEFAULT 0,ts INTEGER,last INTEGER);
CREATE TABLE IF NOT EXISTS f_posts(id INTEGER PRIMARY KEY AUTOINCREMENT,tid INTEGER,uid TEXT,body TEXT,ts INTEGER)');
$CATS = require __DIR__ . '/categories.php';
// v0.2: retire the categories marked for removal without deleting their topics.
$db->exec('CREATE TABLE IF NOT EXISTS site_migrations (migration TEXT PRIMARY KEY, applied INTEGER NOT NULL)');
$mig = $db->prepare('INSERT OR IGNORE INTO site_migrations(migration, applied) VALUES(?, ?)');
$mig->execute(['forum_categories_v02', time()]);
if ($mig->rowCount() > 0) $db->exec('UPDATE f_topics SET cat=3 WHERE cat IN (1, 2, 4, 5)');
function ftx($v) { global $L; return is_array($v) ? ($v[$L] ?? reset($v)) : (string)$v; }
function fav($r) { return e(avatar(['id' => $r['uid'], 'avatar' => $r['avatar'], 'avu' => $r['avu']], 64)); }
function fnf() { http_response_code(404); top(t('not_found'), 'forum'); echo '<section class="lcard"><h1>404</h1><p>' . e(t('not_found')) . '</p><a class="ghost" href="/forum/">' . e(t('back')) . '</a></section>'; bottom(); exit; }
function forum_action_form($act, $label, $extra = '') { return '<form method="post"><input type="hidden" name="t" value="' . csrf() . '"><input type="hidden" name="act" value="' . $act . '">' . $extra . '<button class="ghost" type="submit">' . e($label) . '</button></form>'; }
function ago($ts) { $d = time() - (int)$ts; return $d < 3600 ? max(1, intdiv($d, 60)) . 'm' : ($d < 86400 ? intdiv($d, 3600) . 'h' : intdiv($d, 86400) . 'd'); }
function fside($cid = 0) { global $CATS; $o = '<nav class="fside"><a' . ($cid === -1 ? ' class="on"' : '') . ' href="/forum/?l=1">' . e(t('topics_all')) . '</a><p>' . e(t('forum')) . '</p>';
  foreach ($CATS as $id => $c) $o .= '<a' . ($id === $cid ? ' class="on"' : '') . ' href="/forum/?c=' . (int)$id . '"><i style="background:' . (col($c['color'] ?? '') ?: '#2ecc71') . '"></i>' . e(ftx($c['name'])) . '</a>';
  echo $o . '<a' . ($cid === 0 ? ' class="on"' : '') . ' href="/forum/">' . e(t('all_cats')) . '</a></nav>'; }
