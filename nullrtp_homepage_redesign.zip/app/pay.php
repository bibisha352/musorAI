<?php // оплата: Stripe, PayPal, ЮKassa (карты/СБП), ЮMoney, ссылки и ручные реквизиты. Ключи — в app/config.php, блок 'pay'.
function pay_http($url, $o = []) { $ch = curl_init($url); $op = [CURLOPT_RETURNTRANSFER => 1, CURLOPT_TIMEOUT => 20, CURLOPT_HTTPHEADER => $o['h'] ?? []];
  if (isset($o['auth'])) $op[CURLOPT_USERPWD] = $o['auth'];
  if (isset($o['post'])) { $op[CURLOPT_POST] = 1; $op[CURLOPT_POSTFIELDS] = $o['post']; }
  curl_setopt_array($ch, $op); return json_decode((string)curl_exec($ch), true) ?: []; }
function pay_amt($o) { return trim(substr(strstr($o['price'], ' '), 1)); }
function pay_cur($o) { return strtoupper(strtok($o['price'], ' ')); }
function pay_ret($o) { global $C; return $C['site'] . '/shop/order/?a=' . $o['k1'] . '&b=' . $o['k2'] . '&n=' . $o['n']; }
function pp_base($P) { return !empty($P['sandbox']) ? 'https://api-m.sandbox.paypal.com' : 'https://api-m.paypal.com'; }
function pp_token($P) { $r = pay_http(pp_base($P) . '/v1/oauth2/token', ['auth' => ($P['id'] ?? '') . ':' . ($P['secret'] ?? ''), 'post' => 'grant_type=client_credentials']); return $r['access_token'] ?? ''; }
function pay_start($o, $m) { global $C; $P = $C['pay'] ?? []; $amt = pay_amt($o); $cur = pay_cur($o); $ret = pay_ret($o); $ti = 'Order #' . $o['n'];
  switch ($m['type'] ?? 'manual') {
    case 'stripe': $k = $P['stripe']['key'] ?? ''; if (!$k) break;
      $r = pay_http('https://api.stripe.com/v1/checkout/sessions', ['auth' => "$k:", 'post' => http_build_query(['mode' => 'payment', 'success_url' => $ret, 'cancel_url' => $ret, 'client_reference_id' => (string)$o['n'], 'line_items' => [['quantity' => 1, 'price_data' => ['currency' => strtolower($cur), 'unit_amount' => (int)round($amt * 100), 'product_data' => ['name' => $ti]]]]])]);
      return ['url' => $r['url'] ?? '', 'pid' => $r['id'] ?? ''];
    case 'yookassa': $y = $P['yookassa'] ?? []; if (empty($y['shop'])) break;
      $b = ['amount' => ['value' => number_format((float)$amt, 2, '.', ''), 'currency' => $cur], 'capture' => true, 'confirmation' => ['type' => 'redirect', 'return_url' => $ret], 'description' => $ti, 'metadata' => ['order' => (string)$o['n']]];
      if (!empty($m['pm'])) $b['payment_method_data'] = ['type' => $m['pm']];
      $r = pay_http('https://api.yookassa.ru/v3/payments', ['auth' => $y['shop'] . ':' . ($y['key'] ?? ''), 'h' => ['Content-Type: application/json', 'Idempotence-Key: ' . bin2hex(random_bytes(12))], 'post' => json_encode($b)]);
      return ['url' => $r['confirmation']['confirmation_url'] ?? '', 'pid' => $r['id'] ?? ''];
    case 'yoomoney': $w = $P['yoomoney']['wallet'] ?? ''; if (!$w || $cur !== 'RUB') break;
      return ['url' => 'https://yoomoney.ru/quickpay/confirm?' . http_build_query(['receiver' => $w, 'quickpay-form' => 'button', 'targets' => $ti, 'paymentType' => $m['pt'] ?? 'AC', 'sum' => $amt, 'label' => (string)$o['n'], 'successURL' => $ret]), 'pid' => 'ym'];
    case 'paypal': $pp = $P['paypal'] ?? []; if (empty($pp['id'])) break; $tk = pp_token($pp); if (!$tk) break;
      $r = pay_http(pp_base($pp) . '/v2/checkout/orders', ['h' => ["Authorization: Bearer $tk", 'Content-Type: application/json'], 'post' => json_encode(['intent' => 'CAPTURE', 'purchase_units' => [['reference_id' => (string)$o['n'], 'amount' => ['currency_code' => $cur, 'value' => number_format((float)$amt, 2, '.', '')]]], 'payment_source' => ['paypal' => ['experience_context' => ['return_url' => $ret, 'cancel_url' => $ret]]]])]);
      $u = ''; foreach ($r['links'] ?? [] as $l) if (in_array($l['rel'] ?? '', ['payer-action', 'approve'], true)) $u = $l['href'];
      return ['url' => $u, 'pid' => $r['id'] ?? ''];
    case 'crypto': $A = $m['addr'] ?? ''; $coin = $m['coin'] ?? ''; $rate = crypto_rate(['USDT' => 'tether', 'BTC' => 'bitcoin', 'TON' => 'the-open-network', 'SOL' => 'solana'][$coin] ?? '', $cur); if (!$A || !$rate) break;
      $base = (float)$amt / $rate; $n = (int)$o['n']; // сумма в монете + уникальный «хвост», чтобы узнать платёж именно по этому заказу
      switch ($coin) { case 'USDT': $u = (int)(ceil($base * 100) * 10000) + ($n % 999 + 1); $dec = 6; break; case 'BTC': $u = (int)(ceil($base * 1e5) * 1000) + ($n % 999 + 1); $dec = 8; break; case 'TON': $u = (int)(ceil($base * 100) * 1e7); $dec = 9; break; default: $u = (int)(ceil($base * 1e4) * 1e5) + ($n % 9999 + 1); $dec = 9; }
      return ['url' => '', 'pid' => 'crypto', 'cx' => json_encode(['coin' => $coin, 'units' => $u, 'amt' => rtrim(rtrim(number_format($u / pow(10, $dec), $dec, '.', ''), '0'), '.'), 'addr' => $A, 'memo' => $coin === 'TON' ? 'nrtp' . $n : ''])];
    case 'link': if (!empty($m['url'])) return ['url' => strtr($m['url'], ['{amount}' => $amt, '{order}' => $o['n'], '{cur}' => $cur]), 'pid' => '']; }
  return ['url' => '', 'pid' => '']; }
function pay_check($o, $m) { global $C; $P = $C['pay'] ?? []; $pid = (string)($o['pid'] ?? ''); $amt = pay_amt($o); if (!$pid || $pid === 'ym') return false; $e = urlencode($pid);
  switch ($m['type'] ?? '') {
    case 'stripe': $r = pay_http("https://api.stripe.com/v1/checkout/sessions/$e", ['auth' => ($P['stripe']['key'] ?? '') . ':']);
      return ($r['payment_status'] ?? '') === 'paid' && (int)($r['amount_total'] ?? 0) === (int)round($amt * 100);
    case 'yookassa': $y = $P['yookassa'] ?? []; $r = pay_http("https://api.yookassa.ru/v3/payments/$e", ['auth' => ($y['shop'] ?? '') . ':' . ($y['key'] ?? '')]);
      return ($r['status'] ?? '') === 'succeeded' && !empty($r['paid']) && abs((float)($r['amount']['value'] ?? 0) - (float)$amt) < 0.01;
    case 'crypto': return crypto_check($o, $m);
    case 'paypal': $pp = $P['paypal'] ?? []; $tk = pp_token($pp); if (!$tk) return false; $h = ["Authorization: Bearer $tk", 'Content-Type: application/json'];
      $r = pay_http(pp_base($pp) . "/v2/checkout/orders/$e", ['h' => $h]);
      if (($r['status'] ?? '') === 'APPROVED') $r = pay_http(pp_base($pp) . "/v2/checkout/orders/$e/capture", ['h' => $h, 'post' => '{}']);
      return ($r['status'] ?? '') === 'COMPLETED' && abs((float)($r['purchase_units'][0]['payments']['captures'][0]['amount']['value'] ?? 0) - (float)$amt) < 0.01; }
  return false; }

function crypto_rate($id, $cur) { global $db; if (!$id) return 0.0; $cur = strtolower($cur); $k = "$id:$cur"; // курс CoinGecko, кэш 10 минут
  $db->exec('CREATE TABLE IF NOT EXISTS rates(k TEXT PRIMARY KEY,v REAL,ts INTEGER)'); $q = $db->prepare('SELECT v,ts FROM rates WHERE k=?'); $q->execute([$k]); $r = $q->fetch(PDO::FETCH_ASSOC);
  if ($r && time() - $r['ts'] < 600) return (float)$r['v'];
  $j = pay_http('https://api.coingecko.com/api/v3/simple/price?ids=' . $id . '&vs_currencies=' . $cur); $v = (float)($j[$id][$cur] ?? 0);
  if ($v > 0) { $db->prepare('INSERT OR REPLACE INTO rates(k,v,ts) VALUES(?,?,?)')->execute([$k, $v, time()]); return $v; }
  return $r ? (float)$r['v'] : 0.0; }
function crypto_check($o, $m) { global $C; $x = json_decode((string)($o['cx'] ?? ''), true); if (!$x) return false; $A = $x['addr']; $u = (int)$x['units']; $t0 = (int)$o['ts'] - 60;
  switch ($x['coin']) {
    case 'USDT': $h = !empty($C['pay']['trongrid']) ? ['TRON-PRO-API-KEY: ' . $C['pay']['trongrid']] : [];
      $r = pay_http('https://api.trongrid.io/v1/accounts/' . $A . '/transactions/trc20?only_to=true&limit=60&contract_address=TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t&min_timestamp=' . ($t0 * 1000), ['h' => $h]);
      foreach ($r['data'] ?? [] as $tx) if ((string)($tx['value'] ?? '') === (string)$u && ($tx['to'] ?? '') === $A) return true; return false;
    case 'TON': $r = pay_http('https://toncenter.com/api/v2/getTransactions?limit=40&address=' . urlencode($A));
      foreach ($r['result'] ?? [] as $tx) { $im = $tx['in_msg'] ?? []; if (($tx['utime'] ?? 0) >= $t0 && trim((string)($im['message'] ?? '')) === $x['memo'] && (int)($im['value'] ?? 0) >= $u * 0.99) return true; } return false;
    case 'BTC': $r = pay_http('https://blockstream.info/api/address/' . urlencode($A) . '/txs'); // нужно 1 подтверждение
      foreach ($r as $tx) if (!empty($tx['status']['confirmed']) && ($tx['status']['block_time'] ?? 0) >= $t0) foreach ($tx['vout'] ?? [] as $v) if (($v['scriptpubkey_address'] ?? '') === $A && (int)$v['value'] === $u) return true; return false;
    case 'SOL': $rpc = fn($mt, $p) => pay_http('https://api.mainnet-beta.solana.com', ['h' => ['Content-Type: application/json'], 'post' => json_encode(['jsonrpc' => '2.0', 'id' => 1, 'method' => $mt, 'params' => $p])])['result'] ?? [];
      foreach ($rpc('getSignaturesForAddress', [$A, ['limit' => 15]]) as $sg) { if (($sg['blockTime'] ?? 0) < $t0 || !empty($sg['err'])) continue;
        $tx = $rpc('getTransaction', [$sg['signature'], ['encoding' => 'jsonParsed', 'maxSupportedTransactionVersion' => 0]]);
        foreach ($tx['transaction']['message']['accountKeys'] ?? [] as $i => $k) if ((is_array($k) ? ($k['pubkey'] ?? '') : $k) === $A && ((int)($tx['meta']['postBalances'][$i] ?? 0) - (int)($tx['meta']['preBalances'][$i] ?? 0)) === $u) return true; } return false; }
  return false; }
