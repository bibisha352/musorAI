<?php // одноразовые приглашения в Discord: бот создаёт инвайт (1 использование, 5 минут), сайт отдаёт его через папку со случайным именем (живёт 10 минут)
define('INV_DIR', dirname(__DIR__) . '/discord-invite-private');
function invite_rm($p) { foreach (glob($p . '/*') ?: [] as $f) @unlink($f); @rmdir($p); }
function invite_sweep() { if (!is_dir(INV_DIR)) return;
  foreach (scandir(INV_DIR) as $d) if (preg_match('/^[a-f0-9]{32}$/', $d) && is_dir(INV_DIR . "/$d") && time() - filemtime(INV_DIR . "/$d") > 600) invite_rm(INV_DIR . "/$d"); }
function invite_make($uid) { global $db, $C; invite_sweep(); // возвращает [папка, ошибка]
  if (empty($C['bot_token']) || empty($C['guild_id'])) return [null, 'в app/config.php нет bot_token или guild_id'];
  $db->exec('CREATE TABLE IF NOT EXISTS invites(uid TEXT PRIMARY KEY,dir TEXT,ts INTEGER)');
  $q = $db->prepare('SELECT * FROM invites WHERE uid=?'); $q->execute([$uid]); $r = $q->fetch(PDO::FETCH_ASSOC);
  if ($r && time() - $r['ts'] < 300 && is_dir(INV_DIR . '/' . $r['dir'])) return [$r['dir'], '']; // не чаще одного приглашения в 5 минут
  if ($r) invite_rm(INV_DIR . '/' . $r['dir']);
  $ch = $C['invite_channel'] ?? ''; $lc = 0;
  if (!$ch) { [$lc, $list] = dc('GET', "/guilds/{$C['guild_id']}/channels", null, null, true); if ($lc == 200) foreach ($list as $x) if (($x['type'] ?? -1) === 0) { $ch = $x['id']; break; } }
  if (!$ch) return [null, 'не найден канал для приглашения (Discord API: HTTP ' . $lc . '). Проверь токен и права бота или задай invite_channel'];
  [$c, $inv] = dc('POST', "/channels/$ch/invites", null, ['max_age' => 300, 'max_uses' => 1, 'unique' => true], true);
  if ($c != 200 || empty($inv['code'])) return [null, 'Discord API: HTTP ' . $c . ' ' . json_encode($inv, JSON_UNESCAPED_UNICODE)];
  $dir = bin2hex(random_bytes(16)); $p = INV_DIR . "/$dir"; if (!@mkdir($p, 0755, true)) return [null, 'не удалось создать папку discord-invite-private (права на запись)'];
  file_put_contents("$p/index.php", "<?php // одноразовая страница приглашения: живёт 10 минут, открывается только тем, кто её запросил\nrequire dirname(__DIR__, 2) . '/app/boot.php';\n\$uid = " . var_export((string)$uid, true) . '; $code = ' . var_export((string)$inv['code'], true) . '; $t = ' . time() . ";\nif (time() - \$t > 600) { foreach (glob(__DIR__ . '/*') as \$f) @unlink(\$f); @rmdir(__DIR__); }\nif (time() - \$t > 600 || empty(\$_SESSION['uid']) || \$_SESSION['uid'] !== \$uid) { http_response_code(404); readfile(dirname(__DIR__, 2) . '/404.html'); exit; }\nheader('Location: https://discord.gg/' . \$code);\n");
  $db->prepare('INSERT OR REPLACE INTO invites(uid,dir,ts) VALUES(?,?,?)')->execute([$uid, $dir, time()]);
  return [$dir, '']; }
