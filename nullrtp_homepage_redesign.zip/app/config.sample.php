<?php // скопируй в app/config.php и заполни
return [
  'site'          => 'https://nullrtp.dev',
  'mail_from'     => 'no-reply@nullrtp.dev', // от этого имени уходят письма регистрации
  'admins'        => ['твоя@почта.com'],     // подтверждённые почты админов (видят все тикеты, назначают роли, модерируют форум)
  'smtp'          => ['host' => '', 'port' => 465, 'secure' => 'ssl', 'user' => 'no-reply@nullrtp.dev', 'pass' => ''], // SMTP почтового ящика (см. панель хостинга: Почта). host пустой = обычный mail()
  'mail_debug'    => false,                  // true: при ошибке отправки письма на странице регистрации покажется причина
  'client_id'     => '',                     // Discord-приложение для привязки аккаунта (OAuth2)
  'client_secret' => '',
  'google_client_id' => '',            // Google OAuth 2.0 client ID
  'google_client_secret' => '',        // Google OAuth 2.0 client secret
  'rc_site'       => '',                     // reCAPTCHA v2 (флажок «Я не робот»): ключ сайта. Пусто = проверка выключена
  'rc_secret'     => '',                     // reCAPTCHA v2: секретный ключ
  'bot_token'     => '',                     // Discord-бот для приглашений (право Create Invite)
  'guild_id'      => '',                     // ID вашего Discord-сервера
  'invite_channel'=> '',                     // ID канала для приглашений (пусто = первый текстовый)
  'youtube'       => '',
];
