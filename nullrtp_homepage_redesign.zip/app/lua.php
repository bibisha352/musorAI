<?php // СТРАНИЦА nullrtp Lua (/lua/). Когда выйдет релиз: status => 'release', впиши версию и ссылку на файл (url).
return [
  'members_only' => true, // true: ссылки на скачивание видят только вошедшие
  'platforms' => [        // status: dev (в разработке) | planned (планируется) | release (можно скачать)
    'gamesense' => ['status' => 'dev', 'ver' => '', 'url' => ''],
    'neverlose' => ['status' => 'planned', 'ver' => '', 'url' => ''],
    'fatality'  => ['status' => 'planned', 'ver' => '', 'url' => ''],
  ],
  'changelog' => [ // ['версия', 'дата', ['ru' => 'что изменилось', 'ua' => '…', 'en' => '…']]
  ],
];
