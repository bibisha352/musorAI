<?php // для планировщика (cron) каждые 5–10 минут: php app/sweep.php — удаляет просроченные папки приглашений
require __DIR__ . '/invite.php'; invite_sweep();
