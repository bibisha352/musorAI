<?php require __DIR__ . '/../app/boot.php';
$u = me();
if (!$u) { top('discord'); logincard('/discord/'); bottom(); exit; } // только для вошедших
$msg = '';
if (!is_file(__DIR__ . '/../app/invite.php')) $msg = admin() ? 'нет файла app/invite.php — загрузи его на сервер' : t('inv_fail');
else { require __DIR__ . '/../app/invite.php'; [$d, $why] = invite_make($u['id']); if ($d) go('/discord-invite-private/' . $d . '/'); $msg = admin() ? $why : t('inv_fail'); }
top('discord'); echo '<section class="lcard"><h1>Discord</h1><p>' . e($msg) . '</p><a class="ghost" href="/profile/">' . e(t('back')) . '</a></section>'; bottom();
