<?php require __DIR__ . '/../app/boot.php';
$n = valid_next($_GET['next'] ?? $_POST['next'] ?? '/profile/'); if (me()) go($n);
$GLOBALS['lerr'] = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') { $lg = trim((string)($_POST['login'] ?? '')); $pw = (string)($_POST['pass'] ?? '');
  if (!throttle(ipk('l'), 12, 900)) $GLOBALS['lerr'] = t('e_try');
  elseif (!captcha_ok()) $GLOBALS['lerr'] = t('e_human');
  else { $q = $db->prepare('SELECT * FROM users WHERE pass IS NOT NULL AND (lower(name)=lower(?) OR lower(email)=lower(?)) LIMIT 1'); $q->execute([$lg, $lg]); $u = $q->fetch(PDO::FETCH_ASSOC);
    if (!$u || !password_verify($pw, $u['pass'])) $GLOBALS['lerr'] = t('e_bad');
    elseif (!$u['verified']) $GLOBALS['lerr'] = t('e_unver');
    else { login_session($u); go($n); } } }
top(t('login')); logincard($n); bottom();
