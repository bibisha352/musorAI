<?php // публичная отдача аватаров и баннеров профиля
$id = preg_replace('/[^a-z0-9]/i', '', (string)($_GET['u'] ?? '')); $k = ($_GET['k'] ?? '') === 'bn' ? 'bn' : 'av';
$f = __DIR__ . "/app/uploads/u/$id-$k.jpg";
if (!$id || !is_file($f)) { http_response_code(404); exit; }
header('Content-Type: image/jpeg'); header('X-Content-Type-Options: nosniff'); header('Cache-Control: public, max-age=86400'); readfile($f);
