<?php require __DIR__ . '/../app/boot.php';
$TR += ['nc_desc' => 'Мод для клиента Discord на основе Vencord.|Мод для клієнта Discord на основі Vencord.|A Discord client mod based on Vencord.', 'nc_st' => 'в разработке|у розробці|in development',
  'nc_lic' => 'NullCore основан на Vencord (GPL-3.0): лицензия, авторство и исходный код сохраняются.|NullCore базується на Vencord (GPL-3.0): ліцензія, авторство та вихідний код зберігаються.|NullCore is based on Vencord (GPL-3.0): the license, attribution and source code are kept.', 'nc_forum' => 'обсуждение на форуме|обговорення на форумі|discuss on the forum'];
top('NullCore'); ?>
<section class="lcard wide ncp"><img src="/assets/img/nullcore.svg" alt=""><h1>NullCore</h1><div class="tk-h"><span class="role alt"><?= e(t('nc_st')) ?></span></div>
  <p style="margin-top:18px;color:#c8ccd4"><?= e(t('nc_desc')) ?></p><p><?= e(t('nc_lic')) ?></p>
  <div class="pact"><a class="btn-green" href="/forum/?c=2"><?= e(t('nc_forum')) ?></a><a class="ghost" href="/support/"><?= e(t('support')) ?></a><a class="ghost" href="/"><?= e(t('back')) ?></a></div></section>
<?php bottom();
