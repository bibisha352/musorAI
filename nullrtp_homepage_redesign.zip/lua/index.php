<?php require __DIR__ . '/../app/boot.php';
$P = require __DIR__ . '/../app/lua.php'; $u = me();
$T = ['ru' => ['sub' => 'Lua-скрипт для CS:GO (HvH) под gamesense, neverlose и fatality.', 'dev' => 'в разработке', 'planned' => 'планируется', 'release' => 'релиз', 'soon' => 'скоро', 'dl' => 'скачать', 'dlogin' => 'войдите, чтобы скачать', 'plat' => 'платформы', 'feat' => 'в планах', 'chg' => 'история версий', 'none' => 'Пока релизов нет. Первым будет gamesense.', 'first' => 'первая',
  'f' => ['menu: вкладки и разделы, как в других gamesense-скриптах', 'anti-aim: отдельный раздел, настройка extended yaw', 'visuals: fog, skybox и другое', 'платформы: сначала gamesense, затем neverlose и fatality'],
  'disc' => 'Сторонний скрипт. nullrtp не связан с Valve, gamesense, neverlose и fatality. Используете на свой риск: возможны блокировки аккаунта.'],
 'ua' => ['sub' => 'Lua-скрипт для CS:GO (HvH) під gamesense, neverlose і fatality.', 'dev' => 'у розробці', 'planned' => 'планується', 'release' => 'реліз', 'soon' => 'скоро', 'dl' => 'завантажити', 'dlogin' => 'увійдіть, щоб завантажити', 'plat' => 'платформи', 'feat' => 'у планах', 'chg' => 'історія версій', 'none' => 'Поки що релізів немає. Першим буде gamesense.', 'first' => 'перша',
  'f' => ['menu: вкладки та розділи, як в інших gamesense-скриптах', 'anti-aim: окремий розділ, налаштування extended yaw', 'visuals: fog, skybox та інше', 'платформи: спочатку gamesense, потім neverlose і fatality'],
  'disc' => 'Сторонній скрипт. nullrtp не пов’язаний з Valve, gamesense, neverlose і fatality. Ви користуєтесь на свій ризик: можливі блокування акаунта.'],
 'en' => ['sub' => 'A Lua script for CS:GO (HvH) for gamesense, neverlose and fatality.', 'dev' => 'in development', 'planned' => 'planned', 'release' => 'release', 'soon' => 'soon', 'dl' => 'download', 'dlogin' => 'log in to download', 'plat' => 'platforms', 'feat' => 'planned', 'chg' => 'changelog', 'none' => 'No releases yet. gamesense comes first.', 'first' => 'first',
  'f' => ['menu: tabs and sections, like other gamesense scripts', 'anti-aim: its own section, extended yaw settings', 'visuals: fog, skybox and more', 'platforms: gamesense first, then neverlose and fatality'],
  'disc' => 'Third-party script. nullrtp is not affiliated with Valve, gamesense, neverlose or fatality. Use at your own risk: account bans are possible.']];
$X = $T[$L]; $col = ['gamesense' => '#84cc16', 'neverlose' => '#38bdf8', 'fatality' => '#f43f5e'];
top('nullrtp Lua'); ?>
<section class="hero c lh">
  <img class="lg-i" src="/assets/img/lua.svg" alt="">
  <h1>nullrtp<span> Lua</span></h1>
  <p class="lead"><?= e($X['sub']) ?></p>
  <p class="kicker"><?= e($X['plat']) ?></p>
</section>
<div class="grid plats"><?php foreach ($P['platforms'] as $n => $p) { $s = $p['status'] ?? 'planned'; $c = $col[$n] ?? '#2ecc71';
  echo '<article class="card prod" style="--pc:' . $c . '"><h2>' . e($n) . '</h2><p><em class="st">' . e($X[$s] ?? $s) . '</em>' . (!empty($p['ver']) ? ' <small>v' . e($p['ver']) . '</small>' : '') . ($n === array_key_first($P['platforms']) ? ' <small>· ' . e($X['first']) . '</small>' : '') . '</p><div class="buy">';
  if ($s === 'release' && !empty($p['url'])) echo (!$P['members_only'] || $u) ? '<a class="btn-green" href="' . e($p['url']) . '">' . e($X['dl']) . '</a>' : '<a class="ghost" href="/login/?next=/lua/">' . e($X['dlogin']) . '</a>';
  else echo '<span class="ghost off">' . e($X['soon']) . '</span>';
  echo '</div></article>'; } ?></div>
<section class="section" style="max-width:820px;margin:0 auto"><p class="kicker"><?= e($X['feat']) ?></p>
  <div class="term"><?php foreach ($X['f'] as $l) { [$k, $v] = array_pad(explode(': ', $l, 2), 2, ''); echo '<div><span>></span> ' . e($k) . ': ' . e($v) . '</div>'; } ?></div></section>
<section class="section" style="max-width:820px;margin:0 auto"><p class="kicker"><?= e($X['chg']) ?></p>
  <div class="tlist"><?php foreach ($P['changelog'] as $c) echo '<div class="trow"><b>v' . e($c[0]) . '</b><span>' . e(is_array($c[2]) ? ($c[2][$L] ?? reset($c[2])) : $c[2]) . '</span><small>' . e($c[1]) . '</small></div>'; if (!$P['changelog']) echo '<p>' . e($X['none']) . '</p>'; ?></div></section>
<section class="lcard wide"><p style="margin:0 0 16px"><?= e($X['disc']) ?></p>
  <div class="pact" style="margin-top:0"><a class="btn-green" href="/forum/?c=5"><?= e(t('forum')) ?></a><a class="ghost" href="/support/"><?= e(t('support')) ?></a><a class="ghost" href="/"><?= e(t('back')) ?></a></div></section>
<?php bottom();
