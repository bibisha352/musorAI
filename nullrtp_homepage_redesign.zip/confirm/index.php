<?php require __DIR__ . '/../app/boot.php'; // ссылка из письма: /confirm/?emtoken=...  (действует 24 часа)
$tk = (string)($_GET['emtoken'] ?? ''); $u = null;
if (preg_match('/^[a-f0-9]{32}$/', $tk)) { $q = $db->prepare('SELECT * FROM users WHERE evt=? AND verified=0 AND evts>?'); $q->execute([hash('sha256', $tk), time() - 86400]); $u = $q->fetch(PDO::FETCH_ASSOC) ?: null; }
if ($u) { $db->prepare('UPDATE users SET verified=1, evt=NULL WHERE id=?')->execute([$u['id']]); login_session($u); go('/profile/'); }
top(t('login')); plogo(); echo '<section class="lcard modal"><p style="margin:0 0 14px;color:#e8eaee">' . e(t('conf_bad')) . '</p><p class="mlinks"><a href="/resend/">' . e(t('resend_q')) . '</a><a href="/login/">' . e(t('login')) . '</a></p></section>'; bottom();
