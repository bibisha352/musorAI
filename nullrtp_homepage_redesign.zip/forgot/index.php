<?php require __DIR__ . '/../app/boot.php'; require __DIR__ . '/../app/mail.php';
$msg = ''; $err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') { $em = strtolower(trim((string)($_POST['email'] ?? '')));
  if (!throttle(ipk('m'), 5, 600)) $err = t('e_try'); elseif (!captcha_ok()) $err = t('e_human');
  else { $q = $db->prepare('SELECT * FROM users WHERE lower(email)=? AND verified=1'); $q->execute([$em]); $u = $q->fetch(PDO::FETCH_ASSOC);
    if ($u) { $tk = bin2hex(random_bytes(16)); $db->prepare('UPDATE users SET rst=?, rsts=? WHERE id=?')->execute([hash('sha256', $tk), time(), $u['id']]); send_reset($em, $u['name'], $tk); }
    $msg = t('mail_sent'); } }
top(t('forgot')); plogo(); ?>
<section class="lcard modal"><a class="mx" href="/login/" aria-label="close">×</a>
<?php if ($msg) echo '<p style="margin:0;color:#e8eaee">' . e($msg) . '</p>'; else { ?>
  <form method="post" class="tform mf"><input type="email" name="email" placeholder="<?= e(t('f_email')) ?>" required maxlength="100"><?= captcha_widget() ?><?php if ($err) echo '<p class="err">' . e($err) . '</p>'; ?><button class="btn-green wide" type="submit"><?= e(t('send_link')) ?></button></form>
<?php } ?></section>
<?php bottom();
