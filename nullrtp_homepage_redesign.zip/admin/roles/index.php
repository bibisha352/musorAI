<?php require __DIR__ . '/../../app/boot.php'; // роли пользователей: назначает только админ; список ролей — в app/roles.php (порядок = приоритет)
if (!admin()) { http_response_code(404); readfile(__DIR__ . '/../../404.html'); exit; }
$R = array_values($RL);
if ($_SERVER['REQUEST_METHOD'] === 'POST') { chk(); $pick = array_map('intval', (array)($_POST['r'] ?? [])); $out = [];
  foreach ($R as $i => $r) if (in_array($i, $pick, true)) $out[] = $r;
  $db->prepare('UPDATE users SET roles=? WHERE id=?')->execute([json_encode($out, JSON_UNESCAPED_UNICODE), (string)($_POST['uid'] ?? '')]); go('/admin/roles/'); }
$us = $db->query('SELECT id,name,email,roles FROM users ORDER BY joined DESC LIMIT 300')->fetchAll(PDO::FETCH_ASSOC);
top(t('adm_roles')); ?>
<section class="lcard wide"><h1><?= e(t('adm_roles')) ?></h1><input id="q" class="search" type="search" placeholder="<?= e(t('f_login')) ?>" autocomplete="off">
<div class="tlist"><?php foreach ($us as $x) { $cur = array_map(fn($r) => $r[0], uroles($x));
  echo '<form method="post" class="trow dev" data-s="' . e($x['name'] . ' ' . $x['email']) . '"><input type="hidden" name="t" value="' . csrf() . '"><input type="hidden" name="uid" value="' . e($x['id']) . '"><span><b>' . e($x['name']) . '</b><br><small>' . e($x['email'] ?: '—') . '</small></span>';
  foreach ($R as $i => $r) echo '<label class="chk"><input type="checkbox" name="r[]" value="' . $i . '"' . (in_array($r[0], $cur, true) ? ' checked' : '') . '>' . e($r[0]) . '</label>';
  echo '<button class="ghost" type="submit">' . e(t('save')) . '</button></form>'; } ?></div></section>
<?php bottom();
