<?php require __DIR__ . '/../../app/boot.php';
$adminHost = strtolower(preg_replace('/:\\d+$/', '', (string)($_SERVER['HTTP_HOST'] ?? ''))) === 'admin.nullrtp.dev';
if (!$adminHost) { header('Location: https://admin.nullrtp.dev/mail/', true, 302); exit; }
 require __DIR__ . '/../../app/mail.php'; // проверка отправки почты (только админ)
if (!admin()) { http_response_code(404); readfile(__DIR__ . '/../../404.html'); exit; }
$res = ''; $ok = null; $smtp = !empty($C['smtp']['host']);
if ($_SERVER['REQUEST_METHOD'] === 'POST') { chk(); $to = trim((string)($_POST['to'] ?? ''));
  if (filter_var($to, FILTER_VALIDATE_EMAIL)) { $ok = send_mail($to, 'nullrtp test', mail_html('Hello!', 'Test email', 'If you can read this, sending works.', 'Open site', $C['site'])); $res = $ok ? 'OK: письмо отправлено (' . ($smtp ? 'SMTP' : 'mail()') . '). Проверь «Входящие» и «Спам».' : 'ОШИБКА: ' . ($GLOBALS['mail_err'] ?? '?'); } }
$log = is_file(__DIR__ . '/../../app/mail.log') ? implode("\n", array_slice(file(__DIR__ . '/../../app/mail.log', FILE_IGNORE_NEW_LINES), -8)) : '';
top('mail'); ?>
<section class="lcard wide"><h1>mail</h1>
  <p>отправка: <b><?= $smtp ? 'SMTP (' . e($C['smtp']['host']) . ')' : 'mail() хостинга' ?></b> · от: <b><?= e($C['mail_from'] ?? 'no-reply@nullrtp.dev') ?></b></p>
  <form method="post" class="tform"><input type="hidden" name="t" value="<?= csrf() ?>"><input type="email" name="to" placeholder="email" required value="<?= e($u['email'] ?? me()['email'] ?? '') ?>"><button class="btn-green" type="submit">отправить тест</button></form>
  <?php if ($res) echo '<p class="' . ($ok ? '' : 'err') . '" style="margin-top:14px">' . e($res) . '</p>'; ?>
  <?php if ($log) echo '<p class="kicker" style="margin-top:20px">журнал ошибок</p><pre class="term" style="white-space:pre-wrap">' . e($log) . '</pre>'; ?></section>
<?php bottom();
